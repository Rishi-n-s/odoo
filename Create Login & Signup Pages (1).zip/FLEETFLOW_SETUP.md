# FleetFlow - Complete Setup Guide

## Overview
FleetFlow is a comprehensive fleet and logistics management system with role-based access control (RBAC). This guide will help you set up and use the system.

## Features Implemented

### 1. **Command Center (Main Dashboard)**
- **Purpose**: High-level fleet oversight
- **KPIs**: 
  - Active Fleet count (vehicles on trips)
  - Maintenance Alerts (vehicles in shop)
  - Utilization Rate (% of fleet assigned vs. idle)
  - Pending Cargo (shipments waiting)
- **Filters**: Vehicle Type, Status, Region
- **Access**: All roles

### 2. **Vehicle Registry**
- **Purpose**: CRUD operations for fleet assets
- **Features**:
  - Add/Edit/Delete vehicles
  - Track: Name, Model, License Plate, Type, Capacity, Odometer, Status
  - Manual "Out of Service" toggle
  - Search functionality
- **Access**: Fleet Manager, Dispatcher

### 3. **Trip Dispatcher**
- **Purpose**: Manage deliveries from Point A to Point B
- **Features**:
  - Create trips with vehicle and driver assignment
  - **Validation**: Cargo weight cannot exceed vehicle capacity
  - **Validation**: Expired driver licenses block assignment
  - **Lifecycle**: Draft → Dispatched → Completed/Cancelled
  - Auto-status updates for vehicles and drivers
- **Access**: Fleet Manager, Dispatcher

### 4. **Maintenance & Service Logs**
- **Purpose**: Track vehicle health and service history
- **Features**:
  - Log maintenance work
  - **Auto-Logic**: Adding vehicle to service sets status to "In Shop"
  - Mark services as completed to return vehicle to "Available"
  - Track costs and service dates
- **Access**: Fleet Manager, Safety Officer

### 5. **Expenses & Fuel Logging**
- **Purpose**: Financial tracking per vehicle
- **Features**:
  - Record fuel purchases (liters, cost, odometer, date)
  - Track expenses (Fuel, Maintenance, Insurance, Other)
  - **Calculation**: Automated "Total Operational Cost" per vehicle
  - Vehicle cost summary view
- **Access**: Fleet Manager, Financial Analyst

### 6. **Driver Management**
- **Purpose**: HR and compliance management
- **Features**:
  - **Compliance**: License expiry tracking
  - **Validation**: Expired licenses block trip assignment
  - **Performance**: Trip completion rates and safety scores
  - **Status**: On Duty, Off Duty, Suspended, On Trip
  - Visual alerts for expired licenses
- **Access**: Fleet Manager, Safety Officer, Dispatcher

### 7. **Operational Analytics**
- **Purpose**: Data-driven decision making
- **Metrics**:
  - **Fuel Efficiency**: km/L per vehicle
  - **Vehicle ROI**: (Revenue - Costs) / Acquisition Cost × 100%
  - Total operational costs
  - Fleet-wide statistics
- **Export**: One-click CSV export for reports
- **Access**: Fleet Manager, Financial Analyst

### 8. **User Profile**
- **Purpose**: View account details and permissions
- **Features**:
  - Personal information display
  - Role description and permissions list
  - Account status and creation date
- **Access**: All authenticated users

## Role-Based Access Control (RBAC)

### Fleet Manager
- **Full Access** to all features
- Can manage vehicles, drivers, trips, maintenance, expenses, and analytics

### Dispatcher
- Trip creation and management
- Vehicle and driver assignment
- Access to vehicle registry (read/write)
- Limited to operational features

### Safety Officer
- Driver compliance monitoring
- Maintenance log access
- Safety score management
- License expiry tracking

### Financial Analyst
- Financial reports and analytics
- Expense tracking
- Fuel cost analysis
- ROI calculations
- Data export capabilities

## Database Schema

### Tables Created:
1. **vehicles** - Fleet assets
2. **drivers** - Driver profiles
3. **trips** - Delivery assignments
4. **maintenance_logs** - Service records
5. **fuel_logs** - Fuel purchases
6. **expenses** - General expenses
7. **users** - User accounts (Supabase Auth)

### Key Relationships:
- Trips reference vehicles and drivers
- Fuel logs reference vehicles and optionally trips
- Maintenance logs reference vehicles
- Expenses reference vehicles

## Setup Instructions

### 1. Database Setup
The migrations will automatically create:
- All required tables
- Indexes for performance
- Row Level Security (RLS) policies
- Sample data for testing

### 2. Email Confirmation
**Important**: Email confirmation must be disabled in Supabase for instant signup.

Go to Supabase Dashboard:
1. Navigate to **Authentication** → **Providers** → **Email**
2. **Toggle OFF** the "Confirm email" option
3. Save changes

### 3. First User
Create your first user by signing up with any role. The system supports:
- Fleet Manager (recommended for first user)
- Dispatcher
- Safety Officer
- Financial Analyst

### 4. Sample Data
The system includes sample data:
- 7 vehicles (trucks, vans, bikes)
- 6 drivers with various statuses
- Multiple trips in different stages
- Maintenance logs and fuel records
- Expense tracking examples

## Workflow Example

### Complete Vehicle-to-Delivery Workflow:

1. **Vehicle Intake**: 
   - Add "Van-05" with 500kg capacity
   - Status automatically set to "Available"

2. **Compliance Check**:
   - Add driver "Alex"
   - System verifies license validity
   - License expiry must be in the future

3. **Dispatching**:
   - Create trip assigning "Alex" to "Van-05"
   - Enter cargo weight: 450kg
   - **Validation**: 450 < 500 ✓ (Pass)
   - Status Update: Vehicle & Driver → "On Trip"

4. **Completion**:
   - Mark trip as "Completed"
   - Enter final odometer reading
   - Status Update: Vehicle & Driver → "Available"

5. **Maintenance**:
   - Log "Oil Change" for Van-05
   - **Auto-Logic**: Status → "In Shop"
   - Vehicle hidden from Trip Dispatcher
   - Mark as completed to return to service

6. **Analytics**:
   - System calculates "Cost-per-km"
   - Updates fuel efficiency metrics
   - ROI calculations based on trip data

## Technical Features

### Frontend
- React 18 with TypeScript
- React Router for navigation
- Tailwind CSS for styling
- Radix UI components
- Form validation
- Real-time data updates

### Backend
- Supabase for database and auth
- PostgreSQL with RLS
- Automatic timestamp tracking
- Foreign key constraints
- Database triggers

### Security
- Row Level Security (RLS)
- JWT-based authentication
- Role-based access control
- Protected routes
- Secure API calls

## Navigation

### Sidebar Navigation
The sidebar shows only pages accessible to your role:
- Command Center (all roles)
- Vehicle Registry (Fleet Manager, Dispatcher)
- Trip Dispatcher (Fleet Manager, Dispatcher)
- Maintenance (Fleet Manager, Safety Officer)
- Expenses & Fuel (Fleet Manager, Financial Analyst)
- Driver Management (Fleet Manager, Safety Officer, Dispatcher)
- Analytics (Fleet Manager, Financial Analyst)
- Profile (all roles)

### Access Restrictions
If you try to access a page you don't have permission for:
- You'll be redirected to the Command Center
- A toast notification will explain the restriction

## Testing the System

### Recommended Testing Flow:

1. **Sign up as Fleet Manager** (full access)
2. **Add vehicles** in Vehicle Registry
3. **Add drivers** in Driver Management
4. **Create a trip** in Trip Dispatcher
5. **Dispatch the trip** and watch status changes
6. **Complete the trip**
7. **Log fuel** for the vehicle
8. **Add maintenance** record
9. **View analytics** to see calculated metrics
10. **Export data** to CSV

### Test Different Roles:
- Create multiple accounts with different roles
- Notice how navigation and features change
- Test access restrictions

## Key Validations

1. **Trip Creation**:
   - Cargo weight must not exceed vehicle capacity
   - Driver license must not be expired
   - Both vehicle and driver must be selected

2. **Maintenance**:
   - Automatically changes vehicle status to "In Shop"
   - Removes vehicle from dispatcher availability
   - Completing service returns vehicle to "Available"

3. **Driver Assignment**:
   - License expiry date checked before trip assignment
   - Expired licenses highlighted in red
   - Cannot assign trips to drivers with expired licenses

## Data Export

The Analytics page includes CSV export:
- Vehicle performance metrics
- Fuel efficiency data
- Cost analysis
- ROI calculations
- Suitable for monthly reports and audits

## Support

For questions or issues:
- Check the User Profile page for role permissions
- Review this documentation
- Contact your Fleet Manager or system administrator

---

**FleetFlow v1.0** - Built with React, TypeScript, Supabase, and Tailwind CSS
