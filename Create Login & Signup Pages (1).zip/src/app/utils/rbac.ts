// Role-Based Access Control utilities

export type UserRole = 'Fleet Manager' | 'Dispatcher' | 'Safety Officer' | 'Financial Analyst';

export interface PageAccess {
  path: string;
  label: string;
  icon: string;
  roles: UserRole[];
  description: string;
}

export const PAGE_ACCESS: PageAccess[] = [
  {
    path: '/dashboard',
    label: 'Command Center',
    icon: 'LayoutDashboard',
    roles: ['Fleet Manager', 'Dispatcher', 'Safety Officer', 'Financial Analyst'],
    description: 'Overview and KPIs',
  },
  {
    path: '/dashboard/vehicles',
    label: 'Vehicle Registry',
    icon: 'Truck',
    roles: ['Fleet Manager', 'Dispatcher'],
    description: 'Asset management',
  },
  {
    path: '/dashboard/trips',
    label: 'Trip Dispatcher',
    icon: 'MapPin',
    roles: ['Fleet Manager', 'Dispatcher'],
    description: 'Trip management',
  },
  {
    path: '/dashboard/maintenance',
    label: 'Maintenance',
    icon: 'Wrench',
    roles: ['Fleet Manager', 'Safety Officer'],
    description: 'Service logs',
  },
  {
    path: '/dashboard/expenses',
    label: 'Expenses & Fuel',
    icon: 'DollarSign',
    roles: ['Fleet Manager', 'Financial Analyst'],
    description: 'Financial tracking',
  },
  {
    path: '/dashboard/drivers',
    label: 'Driver Management',
    icon: 'Users',
    roles: ['Fleet Manager', 'Safety Officer', 'Dispatcher'],
    description: 'Driver profiles',
  },
  {
    path: '/dashboard/analytics',
    label: 'Analytics',
    icon: 'BarChart3',
    roles: ['Fleet Manager', 'Financial Analyst'],
    description: 'Reports & insights',
  },
];

export const hasAccess = (userRole: UserRole, path: string): boolean => {
  // Profile is accessible to all authenticated users
  if (path === '/dashboard/profile') {
    return true;
  }

  const page = PAGE_ACCESS.find(p => p.path === path);
  if (!page) {
    return false;
  }

  return page.roles.includes(userRole);
};

export const getAccessiblePages = (userRole: UserRole): PageAccess[] => {
  return PAGE_ACCESS.filter(page => page.roles.includes(userRole));
};
