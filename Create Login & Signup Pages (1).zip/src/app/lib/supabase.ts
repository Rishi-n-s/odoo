import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '/utils/supabase/info';

// Create Supabase client singleton
const supabaseUrl = `https://${projectId}.supabase.co`;
const supabaseClient = createClient(supabaseUrl, publicAnonKey);

export const supabase = supabaseClient;

// Server API base URL
export const API_BASE_URL = `${supabaseUrl}/functions/v1/make-server-66ef3f16`;
