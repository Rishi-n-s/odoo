import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { BarChart3, Download, TrendingUp, Fuel as FuelIcon, Wrench } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Vehicle, FuelLog, MaintenanceLog } from '../types/database';
import { toast } from 'sonner';

interface VehicleAnalytics {
  id: string;
  name: string;
  totalDistance: number;
  totalFuelCost: number;
  totalFuelLiters: number;
  fuelEfficiency: number;
  totalMaintenanceCost: number;
  totalCost: number;
  roi: number;
}

export const Analytics: React.FC = () => {
  const [analytics, setAnalytics] = useState<VehicleAnalytics[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    try {
      setLoading(true);

      const { data: vehicles } = await supabase.from('vehicles').select('*');
      const { data: fuelLogs } = await supabase.from('fuel_logs').select('*');
      const { data: maintenanceLogs } = await supabase.from('maintenance_logs').select('*');
      const { data: trips } = await supabase.from('trips').select('*').eq('status', 'Completed');

      const vehicleAnalytics: VehicleAnalytics[] = (vehicles || []).map(vehicle => {
        const vehicleFuelLogs = (fuelLogs || []).filter(f => f.vehicle_id === vehicle.id);
        const vehicleMaintenanceLogs = (maintenanceLogs || []).filter(m => m.vehicle_id === vehicle.id);
        const vehicleTrips = (trips || []).filter(t => t.vehicle_id === vehicle.id);

        const totalFuelCost = vehicleFuelLogs.reduce((sum, f) => sum + f.cost, 0);
        const totalFuelLiters = vehicleFuelLogs.reduce((sum, f) => sum + f.liters, 0);
        const totalMaintenanceCost = vehicleMaintenanceLogs.reduce((sum, m) => sum + m.cost, 0);
        const totalDistance = vehicleTrips.reduce((sum, t) => sum + t.distance, 0);
        
        const fuelEfficiency = totalFuelLiters > 0 ? totalDistance / totalFuelLiters : 0;
        const totalCost = totalFuelCost + totalMaintenanceCost;
        
        // Mock revenue for ROI calculation (in real app, would come from trip revenue)
        const estimatedRevenue = totalDistance * 2; // $2 per km
        const acquisitionCost = 50000; // Mock acquisition cost
        const roi = acquisitionCost > 0 ? ((estimatedRevenue - totalCost) / acquisitionCost) * 100 : 0;

        return {
          id: vehicle.id,
          name: vehicle.name,
          totalDistance,
          totalFuelCost,
          totalFuelLiters,
          fuelEfficiency,
          totalMaintenanceCost,
          totalCost,
          roi,
        };
      });

      setAnalytics(vehicleAnalytics.sort((a, b) => b.totalCost - a.totalCost));
    } catch (error) {
      console.error('Error loading analytics:', error);
      toast.error('Failed to load analytics');
    } finally {
      setLoading(false);
    }
  };

  const exportToCSV = () => {
    const headers = ['Vehicle', 'Distance (km)', 'Fuel Efficiency (km/L)', 'Fuel Cost', 'Maintenance Cost', 'Total Cost', 'ROI (%)'];
    const rows = analytics.map(a => [
      a.name,
      a.totalDistance.toFixed(0),
      a.fuelEfficiency.toFixed(2),
      a.totalFuelCost.toFixed(2),
      a.totalMaintenanceCost.toFixed(2),
      a.totalCost.toFixed(2),
      a.roi.toFixed(2),
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fleet-analytics-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success('Analytics exported to CSV');
  };

  const totalFleetDistance = analytics.reduce((sum, a) => sum + a.totalDistance, 0);
  const totalFleetCost = analytics.reduce((sum, a) => sum + a.totalCost, 0);
  const averageFuelEfficiency = analytics.length > 0
    ? analytics.reduce((sum, a) => sum + a.fuelEfficiency, 0) / analytics.length
    : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Operational Analytics</h2>
          <p className="text-gray-600 mt-1">Data-driven insights and financial reports</p>
        </div>
        <Button onClick={exportToCSV} className="bg-gradient-to-r from-blue-600 to-indigo-600">
          <Download className="size-4 mr-2" />
          Export CSV
        </Button>
      </div>

      {/* Fleet Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold">{totalFleetDistance.toLocaleString()} km</div>
                <p className="text-sm text-gray-600 mt-1">Total Fleet Distance</p>
              </div>
              <div className="p-3 bg-blue-100 rounded-lg">
                <TrendingUp className="size-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold">${totalFleetCost.toLocaleString()}</div>
                <p className="text-sm text-gray-600 mt-1">Total Operational Cost</p>
              </div>
              <div className="p-3 bg-orange-100 rounded-lg">
                <Wrench className="size-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold">{averageFuelEfficiency.toFixed(2)} km/L</div>
                <p className="text-sm text-gray-600 mt-1">Avg Fuel Efficiency</p>
              </div>
              <div className="p-3 bg-green-100 rounded-lg">
                <FuelIcon className="size-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Vehicle Performance Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="size-5" />
            Vehicle Performance Metrics
          </CardTitle>
          <CardDescription>
            Detailed analytics for each vehicle including fuel efficiency, costs, and ROI
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-gray-500">Loading analytics...</div>
          ) : analytics.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No data available. Add vehicles, trips, and logs to see analytics.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Distance</TableHead>
                    <TableHead>Fuel Efficiency</TableHead>
                    <TableHead>Fuel Cost</TableHead>
                    <TableHead>Maintenance</TableHead>
                    <TableHead>Total Cost</TableHead>
                    <TableHead>ROI</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {analytics.map((vehicle) => (
                    <TableRow key={vehicle.id}>
                      <TableCell className="font-medium">{vehicle.name}</TableCell>
                      <TableCell>{vehicle.totalDistance.toLocaleString()} km</TableCell>
                      <TableCell>
                        <span className={vehicle.fuelEfficiency > 8 ? 'text-green-600 font-semibold' : ''}>
                          {vehicle.fuelEfficiency.toFixed(2)} km/L
                        </span>
                      </TableCell>
                      <TableCell>${vehicle.totalFuelCost.toLocaleString()}</TableCell>
                      <TableCell>${vehicle.totalMaintenanceCost.toLocaleString()}</TableCell>
                      <TableCell className="font-bold">${vehicle.totalCost.toLocaleString()}</TableCell>
                      <TableCell>
                        <span className={vehicle.roi > 0 ? 'text-green-600 font-semibold' : 'text-red-600'}>
                          {vehicle.roi.toFixed(1)}%
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Info Card */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-blue-600 rounded-lg">
              <BarChart3 className="size-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">About These Metrics</h3>
              <div className="text-sm text-gray-600 mt-2 space-y-1">
                <p><strong>Fuel Efficiency:</strong> Total distance traveled divided by total fuel consumed (km/L)</p>
                <p><strong>Total Cost:</strong> Combined fuel and maintenance expenses per vehicle</p>
                <p><strong>ROI:</strong> Return on investment calculated as (Revenue - Costs) / Acquisition Cost × 100%</p>
                <p className="mt-2 text-xs text-gray-500">Export to CSV for detailed monthly reports and payroll audits.</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
