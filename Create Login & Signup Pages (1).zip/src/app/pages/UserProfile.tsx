import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Avatar, AvatarFallback } from '../components/ui/avatar';
import { Badge } from '../components/ui/badge';
import { Separator } from '../components/ui/separator';
import { User, Mail, Calendar, Shield, Building2 } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';

export const UserProfile: React.FC = () => {
  const { user } = useAuth();

  if (!user) return null;

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getRoleDescription = (role: string) => {
    const descriptions = {
      'Fleet Manager': 'Full access to all fleet operations, analytics, and management features',
      'Dispatcher': 'Manage trip assignments, vehicle allocation, and driver scheduling',
      'Safety Officer': 'Oversee driver compliance, maintenance logs, and safety protocols',
      'Financial Analyst': 'Access to financial reports, cost analysis, and operational metrics',
    };
    return descriptions[role as keyof typeof descriptions] || 'FleetFlow user';
  };

  const getRolePermissions = (role: string) => {
    const permissions = {
      'Fleet Manager': [
        'Full system access',
        'Vehicle and driver management',
        'Trip dispatcher access',
        'Maintenance oversight',
        'Financial reports and analytics',
        'User management (if admin)',
      ],
      'Dispatcher': [
        'Trip creation and management',
        'Vehicle assignment',
        'Driver assignment',
        'Real-time fleet tracking',
        'Vehicle registry (read-only)',
      ],
      'Safety Officer': [
        'Driver compliance monitoring',
        'License expiry tracking',
        'Maintenance log access',
        'Safety score management',
        'Service scheduling',
      ],
      'Financial Analyst': [
        'Financial reports and analytics',
        'Expense tracking',
        'Fuel cost analysis',
        'ROI calculations',
        'Data export (CSV/PDF)',
      ],
    };
    return permissions[role as keyof typeof permissions] || [];
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-gray-900">User Profile</h2>
        <p className="text-gray-600 mt-1">Your account information and role permissions</p>
      </div>

      {/* Profile Card */}
      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center gap-6">
            <Avatar className="size-24 bg-gradient-to-r from-blue-600 to-indigo-600">
              <AvatarFallback className="bg-transparent text-white text-2xl font-bold">
                {getInitials(user.name)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <CardTitle className="text-2xl">{user.name}</CardTitle>
              <CardDescription className="text-base mt-1">{user.email}</CardDescription>
              <div className="mt-3">
                <Badge className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-1 text-sm">
                  {user.role}
                </Badge>
              </div>
            </div>
          </div>
        </CardHeader>
        <Separator />
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-blue-100 rounded-lg mt-0.5">
                  <User className="size-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Full Name</p>
                  <p className="text-base font-semibold text-gray-900 mt-1">{user.name}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="p-2 bg-green-100 rounded-lg mt-0.5">
                  <Mail className="size-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Email Address</p>
                  <p className="text-base font-semibold text-gray-900 mt-1">{user.email}</p>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-purple-100 rounded-lg mt-0.5">
                  <Shield className="size-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Role</p>
                  <p className="text-base font-semibold text-gray-900 mt-1">{user.role}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="p-2 bg-orange-100 rounded-lg mt-0.5">
                  <Calendar className="size-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Member Since</p>
                  <p className="text-base font-semibold text-gray-900 mt-1">
                    {format(new Date(user.created_at), 'MMMM dd, yyyy')}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Role Description */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="size-5" />
            Role & Responsibilities
          </CardTitle>
          <CardDescription>{getRoleDescription(user.role)}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6 border border-blue-100">
            <h4 className="font-semibold text-gray-900 mb-3">Your Access Permissions:</h4>
            <ul className="space-y-2">
              {getRolePermissions(user.role).map((permission, index) => (
                <li key={index} className="flex items-start gap-2 text-sm text-gray-700">
                  <span className="text-blue-600 mt-0.5">✓</span>
                  <span>{permission}</span>
                </li>
              ))}
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Account Information */}
      <Card>
        <CardHeader>
          <CardTitle>Account Information</CardTitle>
          <CardDescription>Additional details about your FleetFlow account</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-3 border-b">
              <div>
                <p className="font-medium text-gray-900">Account Status</p>
                <p className="text-sm text-gray-500">Your account is active and in good standing</p>
              </div>
              <Badge className="bg-green-100 text-green-800">Active</Badge>
            </div>
            <div className="flex justify-between items-center py-3 border-b">
              <div>
                <p className="font-medium text-gray-900">User ID</p>
                <p className="text-sm text-gray-500 font-mono">{user.id}</p>
              </div>
            </div>
            <div className="flex justify-between items-center py-3">
              <div>
                <p className="font-medium text-gray-900">Account Created</p>
                <p className="text-sm text-gray-500">
                  {format(new Date(user.created_at), 'EEEE, MMMM dd, yyyy \'at\' h:mm a')}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Help & Support */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-blue-600 rounded-lg">
              <Shield className="size-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-1">Need Help?</h3>
              <p className="text-sm text-gray-600">
                If you have questions about your role or need access to additional features, 
                please contact your Fleet Manager or system administrator.
              </p>
              <p className="text-sm text-gray-600 mt-2">
                <strong>Support:</strong> support@fleetflow.com | <strong>Phone:</strong> 1-800-FLEET-00
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
