import * as React from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { HomePage } from '../components/HomePage';
import { Loader2 } from 'lucide-react';

export function LandingPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  React.useEffect(() => {
    if (!loading && user) {
      navigate('/dashboard');
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Loader2 className="size-12 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading FleetFlow...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <HomePage 
        onShowLogin={() => navigate('/login')} 
        onShowSignup={() => navigate('/signup')} 
      />
    </>
  );
}
