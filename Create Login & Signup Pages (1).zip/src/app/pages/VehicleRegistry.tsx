import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Badge } from '../components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '../components/ui/alert-dialog';
import { Alert, AlertDescription } from '../components/ui/alert';
import { Plus, Edit, Trash2, Search, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Vehicle, VehicleType, VehicleStatus } from '../types/database';
import { toast } from 'sonner';

export const VehicleRegistry: React.FC = () => {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [formData, setFormData] = useState({
    name: '',
    model: '',
    license_plate: '',
    vehicle_type: 'Truck' as VehicleType,
    max_capacity: '',
    odometer: '',
    status: 'Available' as VehicleStatus,
    region: 'North',
  });

  const [validationError, setValidationError] = useState('');

  useEffect(() => {
    loadVehicles();
  }, []);

  const loadVehicles = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('vehicles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setVehicles(data || []);
    } catch (error) {
      console.error('Error loading vehicles:', error);
      toast.error('Failed to load vehicles');
    } finally {
      setLoading(false);
    }
  };

  const validateForm = (): boolean => {
    setValidationError('');

    // Validate name
    if (!formData.name.trim()) {
      setValidationError('Vehicle name is required');
      return false;
    }

    // Validate model
    if (!formData.model.trim()) {
      setValidationError('Vehicle model is required');
      return false;
    }

    // Validate license plate
    if (!formData.license_plate.trim()) {
      setValidationError('License plate is required');
      return false;
    }

    // Validate max capacity
    const maxCapacity = parseFloat(formData.max_capacity);
    if (isNaN(maxCapacity) || maxCapacity <= 0) {
      setValidationError('Max capacity must be a positive number');
      return false;
    }

    // Validate odometer
    const odometer = parseFloat(formData.odometer);
    if (isNaN(odometer) || odometer < 0) {
      setValidationError('Odometer must be a non-negative number');
      return false;
    }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      const vehicleData = {
        ...formData,
        max_capacity: parseFloat(formData.max_capacity),
        odometer: parseFloat(formData.odometer),
      };

      if (selectedVehicle) {
        // Update
        const { error } = await supabase
          .from('vehicles')
          .update(vehicleData)
          .eq('id', selectedVehicle.id);

        if (error) {
          if (error.code === '23505') {
            throw new Error('A vehicle with this license plate already exists');
          }
          throw error;
        }
        toast.success('Vehicle updated successfully');
      } else {
        // Create
        const { error } = await supabase
          .from('vehicles')
          .insert([vehicleData]);

        if (error) {
          if (error.code === '23505') {
            throw new Error('A vehicle with this license plate already exists');
          }
          throw error;
        }
        toast.success('Vehicle added successfully');
      }

      setDialogOpen(false);
      resetForm();
      loadVehicles();
    } catch (error: any) {
      console.error('Error saving vehicle:', error);
      const message = error.message || 'Failed to save vehicle';
      setValidationError(message);
      toast.error(message);
    }
  };

  const handleEdit = (vehicle: Vehicle) => {
    setSelectedVehicle(vehicle);
    setFormData({
      name: vehicle.name,
      model: vehicle.model,
      license_plate: vehicle.license_plate,
      vehicle_type: vehicle.vehicle_type,
      max_capacity: vehicle.max_capacity.toString(),
      odometer: vehicle.odometer.toString(),
      status: vehicle.status,
      region: vehicle.region || 'North',
    });
    setDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!selectedVehicle) return;

    try {
      const { error } = await supabase
        .from('vehicles')
        .delete()
        .eq('id', selectedVehicle.id);

      if (error) throw error;
      toast.success('Vehicle deleted successfully');
      setDeleteDialogOpen(false);
      setSelectedVehicle(null);
      loadVehicles();
    } catch (error: any) {
      console.error('Error deleting vehicle:', error);
      toast.error(error.message || 'Failed to delete vehicle');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      model: '',
      license_plate: '',
      vehicle_type: 'Truck',
      max_capacity: '',
      odometer: '',
      status: 'Available',
      region: 'North',
    });
    setSelectedVehicle(null);
    setValidationError('');
  };

  const getStatusBadge = (status: VehicleStatus) => {
    const styles = {
      'Available': 'bg-green-100 text-green-800',
      'On Trip': 'bg-blue-100 text-blue-800',
      'In Shop': 'bg-orange-100 text-orange-800',
      'Out of Service': 'bg-gray-100 text-gray-800',
    };
    return <Badge className={styles[status]}>{status}</Badge>;
  };

  const filteredVehicles = vehicles.filter(v =>
    v.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.license_plate.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.model.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Vehicle Registry</h2>
          <p className="text-gray-600 mt-1">Manage your fleet assets and vehicle information</p>
        </div>
        <Button onClick={() => { resetForm(); setDialogOpen(true); }} className="bg-gradient-to-r from-blue-600 to-indigo-600">
          <Plus className="size-4 mr-2" />
          Add Vehicle
        </Button>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
            <Input
              placeholder="Search by name, license plate, or model..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Vehicles Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Vehicles</CardTitle>
          <CardDescription>A complete list of all fleet vehicles</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-gray-500">Loading vehicles...</div>
          ) : filteredVehicles.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No vehicles found. {searchTerm && 'Try adjusting your search.'}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name/Model</TableHead>
                    <TableHead>License Plate</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Max Capacity</TableHead>
                    <TableHead>Odometer</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Region</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredVehicles.map((vehicle) => (
                    <TableRow key={vehicle.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{vehicle.name}</div>
                          <div className="text-sm text-gray-500">{vehicle.model}</div>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono">{vehicle.license_plate}</TableCell>
                      <TableCell>{vehicle.vehicle_type}</TableCell>
                      <TableCell>{vehicle.max_capacity} kg</TableCell>
                      <TableCell>{vehicle.odometer.toLocaleString()} km</TableCell>
                      <TableCell>{getStatusBadge(vehicle.status)}</TableCell>
                      <TableCell>{vehicle.region}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button variant="ghost" size="sm" onClick={() => handleEdit(vehicle)}>
                            <Edit className="size-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => { setSelectedVehicle(vehicle); setDeleteDialogOpen(true); }}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="size-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedVehicle ? 'Edit Vehicle' : 'Add New Vehicle'}</DialogTitle>
            <DialogDescription>
              {selectedVehicle ? 'Update vehicle information' : 'Enter details for the new vehicle'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            {validationError && (
              <Alert variant="destructive" className="mx-6 mt-4">
                <AlertCircle className="size-4" />
                <AlertDescription>{validationError}</AlertDescription>
              </Alert>
            )}
            <div className="grid grid-cols-2 gap-4 py-4 px-6">
              <div className="space-y-2">
                <Label htmlFor="name">Vehicle Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., Van-05"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="model">Model *</Label>
                <Input
                  id="model"
                  value={formData.model}
                  onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                  placeholder="e.g., Ford Transit 2023"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="license_plate">License Plate *</Label>
                <Input
                  id="license_plate"
                  value={formData.license_plate}
                  onChange={(e) => setFormData({ ...formData, license_plate: e.target.value })}
                  placeholder="e.g., ABC-1234"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="vehicle_type">Vehicle Type *</Label>
                <Select value={formData.vehicle_type} onValueChange={(value: VehicleType) => setFormData({ ...formData, vehicle_type: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Truck">Truck</SelectItem>
                    <SelectItem value="Van">Van</SelectItem>
                    <SelectItem value="Bike">Bike</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="max_capacity">Max Capacity (kg) *</Label>
                <Input
                  id="max_capacity"
                  type="number"
                  value={formData.max_capacity}
                  onChange={(e) => setFormData({ ...formData, max_capacity: e.target.value })}
                  placeholder="e.g., 500"
                  required
                  min="0"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="odometer">Odometer (km) *</Label>
                <Input
                  id="odometer"
                  type="number"
                  value={formData.odometer}
                  onChange={(e) => setFormData({ ...formData, odometer: e.target.value })}
                  placeholder="e.g., 15000"
                  required
                  min="0"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="status">Status *</Label>
                <Select value={formData.status} onValueChange={(value: VehicleStatus) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Available">Available</SelectItem>
                    <SelectItem value="On Trip">On Trip</SelectItem>
                    <SelectItem value="In Shop">In Shop</SelectItem>
                    <SelectItem value="Out of Service">Out of Service</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="region">Region *</Label>
                <Select value={formData.region} onValueChange={(value) => setFormData({ ...formData, region: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="North">North</SelectItem>
                    <SelectItem value="South">South</SelectItem>
                    <SelectItem value="East">East</SelectItem>
                    <SelectItem value="West">West</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => { setDialogOpen(false); resetForm(); }}>
                Cancel
              </Button>
              <Button type="submit" className="bg-gradient-to-r from-blue-600 to-indigo-600">
                {selectedVehicle ? 'Update Vehicle' : 'Add Vehicle'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete {selectedVehicle?.name}. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setSelectedVehicle(null)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};