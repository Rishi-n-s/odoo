import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { AlertCircle, Plus, MapPin, CheckCircle, XCircle } from 'lucide-react';
import { Alert, AlertDescription } from '../components/ui/alert';
import { supabase } from '../lib/supabase';
import { Trip, TripStatus, Vehicle, Driver } from '../types/database';
import { toast } from 'sonner';

export const TripDispatcher: React.FC = () => {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [allVehicles, setAllVehicles] = useState<Vehicle[]>([]);
  const [allDrivers, setAllDrivers] = useState<Driver[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  
  const [formData, setFormData] = useState({
    vehicle_id: '',
    driver_id: '',
    cargo_weight: '',
    origin: '',
    destination: '',
    distance: '',
    status: 'Draft' as TripStatus,
  });

  const [validationError, setValidationError] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Load trips
      const { data: tripsData, error: tripsError } = await supabase
        .from('trips')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (tripsError) throw tripsError;
      setTrips(tripsData || []);

      // Load all vehicles for lookup
      const { data: allVehiclesData, error: allVehiclesError } = await supabase
        .from('vehicles')
        .select('*');
      
      if (allVehiclesError) throw allVehiclesError;
      setAllVehicles(allVehiclesData || []);
      setVehicles(allVehiclesData?.filter(v => ['Available', 'On Trip'].includes(v.status)) || []);

      // Load all drivers for lookup
      const { data: allDriversData, error: allDriversError } = await supabase
        .from('drivers')
        .select('*');
      
      if (allDriversError) throw allDriversError;
      setAllDrivers(allDriversData || []);
      setDrivers(allDriversData?.filter(d => ['On Duty', 'Off Duty', 'On Trip'].includes(d.status)) || []);
      
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const validateTrip = (): boolean => {
    setValidationError('');

    if (!formData.vehicle_id || !formData.driver_id) {
      setValidationError('Please select both vehicle and driver');
      return false;
    }

    const selectedVehicle = vehicles.find(v => v.id === formData.vehicle_id);
    const selectedDriver = drivers.find(d => d.id === formData.driver_id);
    const cargoWeight = parseFloat(formData.cargo_weight);

    if (!selectedVehicle || !selectedDriver) {
      setValidationError('Invalid vehicle or driver selection');
      return false;
    }

    // Check if driver's license is expired
    if (selectedDriver.license_expiry && new Date(selectedDriver.license_expiry) < new Date()) {
      setValidationError(`Driver ${selectedDriver.name}'s license has expired. Cannot assign to trip.`);
      return false;
    }

    // Validate cargo weight
    if (cargoWeight > selectedVehicle.max_capacity) {
      setValidationError(
        `Cargo weight (${cargoWeight}kg) exceeds vehicle capacity (${selectedVehicle.max_capacity}kg)`
      );
      return false;
    }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateTrip()) {
      return;
    }

    try {
      const tripData = {
        ...formData,
        cargo_weight: parseFloat(formData.cargo_weight),
        distance: parseFloat(formData.distance),
      };

      if (selectedTrip) {
        // Update
        const { error } = await supabase
          .from('trips')
          .update(tripData)
          .eq('id', selectedTrip.id);

        if (error) throw error;
        toast.success('Trip updated successfully');
      } else {
        // Create
        const { error } = await supabase
          .from('trips')
          .insert([tripData]);

        if (error) throw error;
        toast.success('Trip created successfully');
      }

      // Update vehicle and driver status if dispatching
      if (formData.status === 'Dispatched') {
        await supabase.from('vehicles').update({ status: 'On Trip' }).eq('id', formData.vehicle_id);
        await supabase.from('drivers').update({ status: 'On Trip' }).eq('id', formData.driver_id);
      }

      setDialogOpen(false);
      resetForm();
      loadData();
    } catch (error: any) {
      console.error('Error saving trip:', error);
      toast.error(error.message || 'Failed to save trip');
    }
  };

  const handleStatusChange = async (tripId: string, newStatus: TripStatus) => {
    try {
      const trip = trips.find(t => t.id === tripId);
      if (!trip) return;

      const updateData: any = { status: newStatus };

      if (newStatus === 'Completed') {
        updateData.completed_at = new Date().toISOString();
        // Update vehicle and driver to Available
        await supabase.from('vehicles').update({ status: 'Available' }).eq('id', trip.vehicle_id);
        await supabase.from('drivers').update({ status: 'On Duty' }).eq('id', trip.driver_id);
      } else if (newStatus === 'Cancelled') {
        updateData.cancelled_at = new Date().toISOString();
        // Update vehicle and driver to Available
        await supabase.from('vehicles').update({ status: 'Available' }).eq('id', trip.vehicle_id);
        await supabase.from('drivers').update({ status: 'On Duty' }).eq('id', trip.driver_id);
      } else if (newStatus === 'Dispatched') {
        updateData.started_at = new Date().toISOString();
        // Update vehicle and driver to On Trip
        await supabase.from('vehicles').update({ status: 'On Trip' }).eq('id', trip.vehicle_id);
        await supabase.from('drivers').update({ status: 'On Trip' }).eq('id', trip.driver_id);
      }

      const { error } = await supabase
        .from('trips')
        .update(updateData)
        .eq('id', tripId);

      if (error) throw error;
      toast.success(`Trip ${newStatus.toLowerCase()}`);
      loadData();
    } catch (error: any) {
      console.error('Error updating trip status:', error);
      toast.error(error.message || 'Failed to update trip status');
    }
  };

  const resetForm = () => {
    setFormData({
      vehicle_id: '',
      driver_id: '',
      cargo_weight: '',
      origin: '',
      destination: '',
      distance: '',
      status: 'Draft',
    });
    setSelectedTrip(null);
    setValidationError('');
  };

  const getStatusBadge = (status: TripStatus) => {
    const styles = {
      'Draft': 'bg-gray-100 text-gray-800',
      'Dispatched': 'bg-blue-100 text-blue-800',
      'Completed': 'bg-green-100 text-green-800',
      'Cancelled': 'bg-red-100 text-red-800',
    };
    return <Badge className={styles[status]}>{status}</Badge>;
  };

  const getVehicleName = (vehicleId: string) => {
    return allVehicles.find(v => v.id === vehicleId)?.name || 'Unknown';
  };

  const getDriverName = (driverId: string) => {
    return allDrivers.find(d => d.id === driverId)?.name || 'Unknown';
  };

  const renderTripsTable = (tripsList: Trip[]) => (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Vehicle</TableHead>
            <TableHead>Driver</TableHead>
            <TableHead>Route</TableHead>
            <TableHead>Cargo</TableHead>
            <TableHead>Distance</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {tripsList.length === 0 ? (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                No trips found
              </TableCell>
            </TableRow>
          ) : (
            tripsList.map((trip) => (
              <TableRow key={trip.id}>
                <TableCell className="font-medium">{getVehicleName(trip.vehicle_id)}</TableCell>
                <TableCell>{getDriverName(trip.driver_id)}</TableCell>
                <TableCell>
                  <div className="text-sm">
                    <div className="font-medium">{trip.origin}</div>
                    <div className="text-gray-500">→ {trip.destination}</div>
                  </div>
                </TableCell>
                <TableCell>{trip.cargo_weight} kg</TableCell>
                <TableCell>{trip.distance} km</TableCell>
                <TableCell>{getStatusBadge(trip.status)}</TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    {trip.status === 'Draft' && (
                      <Button 
                        size="sm" 
                        onClick={() => handleStatusChange(trip.id, 'Dispatched')}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        Dispatch
                      </Button>
                    )}
                    {trip.status === 'Dispatched' && (
                      <>
                        <Button 
                          size="sm" 
                          onClick={() => handleStatusChange(trip.id, 'Completed')}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="size-4 mr-1" />
                          Complete
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleStatusChange(trip.id, 'Cancelled')}
                          className="text-red-600 hover:text-red-700"
                        >
                          <XCircle className="size-4 mr-1" />
                          Cancel
                        </Button>
                      </>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );

  const availableVehicles = vehicles.filter(v => v.status === 'Available');
  const availableDrivers = drivers.filter(d => 
    (d.status === 'On Duty' || d.status === 'Off Duty') && 
    new Date(d.license_expiry) >= new Date()
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Trip Dispatcher</h2>
          <p className="text-gray-600 mt-1">Manage trip assignments and track deliveries</p>
        </div>
        <Button onClick={() => { resetForm(); setDialogOpen(true); }} className="bg-gradient-to-r from-blue-600 to-indigo-600">
          <Plus className="size-4 mr-2" />
          Create Trip
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{trips.filter(t => t.status === 'Draft').length}</div>
            <p className="text-sm text-gray-600">Draft</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{trips.filter(t => t.status === 'Dispatched').length}</div>
            <p className="text-sm text-gray-600">Active Trips</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{availableVehicles.length}</div>
            <p className="text-sm text-gray-600">Available Vehicles</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{availableDrivers.length}</div>
            <p className="text-sm text-gray-600">Available Drivers</p>
          </CardContent>
        </Card>
      </div>

      {/* Trips Table with Tabs */}
      <Card>
        <CardHeader>
          <CardTitle>All Trips</CardTitle>
          <CardDescription>View and manage trips by status</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-gray-500">Loading trips...</div>
          ) : (
            <Tabs defaultValue="all">
              <TabsList>
                <TabsTrigger value="all">All ({trips.length})</TabsTrigger>
                <TabsTrigger value="draft">Draft ({trips.filter(t => t.status === 'Draft').length})</TabsTrigger>
                <TabsTrigger value="dispatched">Active ({trips.filter(t => t.status === 'Dispatched').length})</TabsTrigger>
                <TabsTrigger value="completed">Completed ({trips.filter(t => t.status === 'Completed').length})</TabsTrigger>
              </TabsList>
              <TabsContent value="all">
                {renderTripsTable(trips)}
              </TabsContent>
              <TabsContent value="draft">
                {renderTripsTable(trips.filter(t => t.status === 'Draft'))}
              </TabsContent>
              <TabsContent value="dispatched">
                {renderTripsTable(trips.filter(t => t.status === 'Dispatched'))}
              </TabsContent>
              <TabsContent value="completed">
                {renderTripsTable(trips.filter(t => t.status === 'Completed'))}
              </TabsContent>
            </Tabs>
          )}
        </CardContent>
      </Card>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              <MapPin className="inline size-5 mr-2" />
              {selectedTrip ? 'Edit Trip' : 'Create New Trip'}
            </DialogTitle>
            <DialogDescription>
              {selectedTrip ? 'Update trip information' : 'Assign vehicle and driver to a new delivery'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="space-y-4 py-4">
              {validationError && (
                <Alert variant="destructive">
                  <AlertCircle className="size-4" />
                  <AlertDescription>{validationError}</AlertDescription>
                </Alert>
              )}
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="vehicle_id">Vehicle *</Label>
                  <Select 
                    value={formData.vehicle_id} 
                    onValueChange={(value) => setFormData({ ...formData, vehicle_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select vehicle" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableVehicles.map(v => (
                        <SelectItem key={v.id} value={v.id}>
                          {v.name} ({v.vehicle_type}, {v.max_capacity}kg capacity)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="driver_id">Driver *</Label>
                  <Select 
                    value={formData.driver_id} 
                    onValueChange={(value) => setFormData({ ...formData, driver_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select driver" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableDrivers.map(d => (
                        <SelectItem key={d.id} value={d.id}>
                          {d.name} ({d.license_category})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="origin">Origin *</Label>
                  <Input
                    id="origin"
                    value={formData.origin}
                    onChange={(e) => setFormData({ ...formData, origin: e.target.value })}
                    placeholder="Starting location"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="destination">Destination *</Label>
                  <Input
                    id="destination"
                    value={formData.destination}
                    onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                    placeholder="Delivery location"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cargo_weight">Cargo Weight (kg) *</Label>
                  <Input
                    id="cargo_weight"
                    type="number"
                    value={formData.cargo_weight}
                    onChange={(e) => setFormData({ ...formData, cargo_weight: e.target.value })}
                    placeholder="e.g., 450"
                    required
                    min="0"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="distance">Distance (km) *</Label>
                  <Input
                    id="distance"
                    type="number"
                    value={formData.distance}
                    onChange={(e) => setFormData({ ...formData, distance: e.target.value })}
                    placeholder="e.g., 120"
                    required
                    min="0"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status *</Label>
                <Select 
                  value={formData.status} 
                  onValueChange={(value: TripStatus) => setFormData({ ...formData, status: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Draft">Draft</SelectItem>
                    <SelectItem value="Dispatched">Dispatched</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => { setDialogOpen(false); resetForm(); }}>
                Cancel
              </Button>
              <Button type="submit" className="bg-gradient-to-r from-blue-600 to-indigo-600">
                {selectedTrip ? 'Update Trip' : 'Create Trip'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};
