import React, { useState, useEffect } from 'react';
import { Link } from 'react-router';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Badge } from '../components/ui/badge';
import { Truck, Wrench, TrendingUp, Package, Filter } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { VehicleType, VehicleStatus } from '../types/database';

interface DashboardStats {
  activeFleet: number;
  maintenanceAlerts: number;
  utilizationRate: number;
  pendingCargo: number;
}

export const CommandCenter: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats>({
    activeFleet: 0,
    maintenanceAlerts: 0,
    utilizationRate: 0,
    pendingCargo: 0,
  });
  const [vehicleTypeFilter, setVehicleTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [regionFilter, setRegionFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardStats();
  }, [vehicleTypeFilter, statusFilter, regionFilter]);

  const loadDashboardStats = async () => {
    try {
      setLoading(true);

      // Build query for vehicles
      let vehicleQuery = supabase.from('vehicles').select('*', { count: 'exact' });
      
      if (vehicleTypeFilter !== 'all') {
        vehicleQuery = vehicleQuery.eq('vehicle_type', vehicleTypeFilter);
      }
      if (statusFilter !== 'all') {
        vehicleQuery = vehicleQuery.eq('status', statusFilter);
      }
      if (regionFilter !== 'all') {
        vehicleQuery = vehicleQuery.eq('region', regionFilter);
      }

      const { data: vehicles, count: totalVehicles } = await vehicleQuery;

      // Calculate stats
      const activeFleet = vehicles?.filter(v => v.status === 'On Trip').length || 0;
      const maintenanceAlerts = vehicles?.filter(v => v.status === 'In Shop').length || 0;
      const assignedVehicles = vehicles?.filter(v => v.status === 'On Trip' || v.status === 'In Shop').length || 0;
      const utilizationRate = totalVehicles ? Math.round((assignedVehicles / totalVehicles) * 100) : 0;

      // Get pending trips (Draft status)
      const { count: pendingTrips } = await supabase
        .from('trips')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'Draft');

      setStats({
        activeFleet,
        maintenanceAlerts,
        utilizationRate,
        pendingCargo: pendingTrips || 0,
      });
    } catch (error) {
      console.error('Error loading dashboard stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const StatCard: React.FC<{
    title: string;
    value: number | string;
    description: string;
    icon: React.ReactNode;
    trend?: 'up' | 'down';
    color: string;
  }> = ({ title, value, description, icon, trend, color }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
        <div className={`p-2 rounded-lg ${color}`}>
          {icon}
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-baseline gap-2">
          <div className="text-3xl font-bold">{value}</div>
          {trend && (
            <TrendingUp className={`size-4 ${trend === 'up' ? 'text-green-600' : 'text-red-600 rotate-180'}`} />
          )}
        </div>
        <p className="text-xs text-gray-500 mt-1">{description}</p>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Command Center</h2>
        <p className="text-gray-600 mt-1">High-level fleet oversight and key performance indicators</p>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="size-5" />
            Filters
          </CardTitle>
          <CardDescription>Filter dashboard data by vehicle type, status, or region</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Vehicle Type</label>
              <Select value={vehicleTypeFilter} onValueChange={setVehicleTypeFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Truck">Truck</SelectItem>
                  <SelectItem value="Van">Van</SelectItem>
                  <SelectItem value="Bike">Bike</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Status</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="Available">Available</SelectItem>
                  <SelectItem value="On Trip">On Trip</SelectItem>
                  <SelectItem value="In Shop">In Shop</SelectItem>
                  <SelectItem value="Out of Service">Out of Service</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Region</label>
              <Select value={regionFilter} onValueChange={setRegionFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Regions</SelectItem>
                  <SelectItem value="North">North</SelectItem>
                  <SelectItem value="South">South</SelectItem>
                  <SelectItem value="East">East</SelectItem>
                  <SelectItem value="West">West</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Active Fleet"
          value={loading ? '...' : stats.activeFleet}
          description="Vehicles currently on trips"
          icon={<Truck className="size-5 text-blue-600" />}
          color="bg-blue-100"
          trend="up"
        />
        <StatCard
          title="Maintenance Alerts"
          value={loading ? '...' : stats.maintenanceAlerts}
          description="Vehicles in the shop"
          icon={<Wrench className="size-5 text-orange-600" />}
          color="bg-orange-100"
        />
        <StatCard
          title="Utilization Rate"
          value={loading ? '...' : `${stats.utilizationRate}%`}
          description="Fleet assigned vs. idle"
          icon={<TrendingUp className="size-5 text-green-600" />}
          color="bg-green-100"
          trend="up"
        />
        <StatCard
          title="Pending Cargo"
          value={loading ? '...' : stats.pendingCargo}
          description="Shipments awaiting assignment"
          icon={<Package className="size-5 text-purple-600" />}
          color="bg-purple-100"
        />
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Common tasks and shortcuts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link 
              to="/dashboard/trips" 
              className="p-4 border rounded-lg hover:bg-gray-50 transition-colors cursor-pointer block"
            >
              <h3 className="font-semibold text-gray-900">Create New Trip</h3>
              <p className="text-sm text-gray-600 mt-1">Assign vehicle and driver</p>
            </Link>
            <Link 
              to="/dashboard/vehicles" 
              className="p-4 border rounded-lg hover:bg-gray-50 transition-colors cursor-pointer block"
            >
              <h3 className="font-semibold text-gray-900">Add Vehicle</h3>
              <p className="text-sm text-gray-600 mt-1">Register new asset</p>
            </Link>
            <Link 
              to="/dashboard/maintenance" 
              className="p-4 border rounded-lg hover:bg-gray-50 transition-colors cursor-pointer block"
            >
              <h3 className="font-semibold text-gray-900">Log Maintenance</h3>
              <p className="text-sm text-gray-600 mt-1">Schedule service</p>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Info Banner */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-blue-600 rounded-lg">
              <Truck className="size-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Welcome to FleetFlow Command Center</h3>
              <p className="text-sm text-gray-600 mt-1">
                Monitor your fleet in real-time. Use filters to narrow down data, and access quick actions for common tasks.
                Your current role provides access to {vehicleTypeFilter === 'all' ? 'all' : vehicleTypeFilter} vehicles.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
