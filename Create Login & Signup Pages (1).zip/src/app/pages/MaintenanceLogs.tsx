import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Badge } from '../components/ui/badge';
import { Checkbox } from '../components/ui/checkbox';
import { Plus, Wrench, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '../components/ui/alert';
import { supabase } from '../lib/supabase';
import { MaintenanceLog, Vehicle } from '../types/database';
import { toast } from 'sonner';
import { format } from 'date-fns';

export const MaintenanceLogs: React.FC = () => {
  const [logs, setLogs] = useState<MaintenanceLog[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedLog, setSelectedLog] = useState<MaintenanceLog | null>(null);
  
  const [formData, setFormData] = useState({
    vehicle_id: '',
    service_type: '',
    description: '',
    cost: '',
    odometer_at_service: '',
    service_date: format(new Date(), 'yyyy-MM-dd'),
    completed: false,
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Load maintenance logs
      const { data: logsData, error: logsError } = await supabase
        .from('maintenance_logs')
        .select('*')
        .order('service_date', { ascending: false });
      
      if (logsError) throw logsError;
      setLogs(logsData || []);

      // Load vehicles
      const { data: vehiclesData, error: vehiclesError } = await supabase
        .from('vehicles')
        .select('*')
        .order('name');
      
      if (vehiclesError) throw vehiclesError;
      setVehicles(vehiclesData || []);
      
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const logData = {
        ...formData,
        cost: parseFloat(formData.cost),
        odometer_at_service: parseFloat(formData.odometer_at_service),
      };

      if (selectedLog) {
        // Update
        const { error } = await supabase
          .from('maintenance_logs')
          .update(logData)
          .eq('id', selectedLog.id);

        if (error) throw error;
        toast.success('Maintenance log updated');
        
        // Update vehicle status if service is started (not completed)
        if (!formData.completed) {
          await supabase
            .from('vehicles')
            .update({ status: 'In Shop' })
            .eq('id', formData.vehicle_id);
        } else {
          // Mark as available if service is completed
          await supabase
            .from('vehicles')
            .update({ status: 'Available' })
            .eq('id', formData.vehicle_id);
        }
      } else {
        // Create
        const { error } = await supabase
          .from('maintenance_logs')
          .insert([logData]);

        if (error) throw error;
        toast.success('Maintenance log created');
        
        // Auto-update vehicle status
        const newStatus = formData.completed ? 'Available' : 'In Shop';
        await supabase
          .from('vehicles')
          .update({ status: newStatus })
          .eq('id', formData.vehicle_id);
      }

      setDialogOpen(false);
      resetForm();
      loadData();
    } catch (error: any) {
      console.error('Error saving maintenance log:', error);
      toast.error(error.message || 'Failed to save maintenance log');
    }
  };

  const handleToggleComplete = async (log: MaintenanceLog) => {
    try {
      const newCompletedStatus = !log.completed;
      
      const { error } = await supabase
        .from('maintenance_logs')
        .update({ completed: newCompletedStatus })
        .eq('id', log.id);

      if (error) throw error;

      // Update vehicle status
      if (newCompletedStatus) {
        // Service completed - set vehicle to Available
        await supabase
          .from('vehicles')
          .update({ status: 'Available' })
          .eq('id', log.vehicle_id);
        toast.success('Service marked as completed. Vehicle is now available.');
      } else {
        // Service not completed - set vehicle to In Shop
        await supabase
          .from('vehicles')
          .update({ status: 'In Shop' })
          .eq('id', log.vehicle_id);
        toast.success('Service marked as in progress. Vehicle is in shop.');
      }

      loadData();
    } catch (error: any) {
      console.error('Error toggling completion:', error);
      toast.error(error.message || 'Failed to update status');
    }
  };

  const handleEdit = (log: MaintenanceLog) => {
    setSelectedLog(log);
    setFormData({
      vehicle_id: log.vehicle_id,
      service_type: log.service_type,
      description: log.description,
      cost: log.cost.toString(),
      odometer_at_service: log.odometer_at_service.toString(),
      service_date: log.service_date,
      completed: log.completed,
    });
    setDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      vehicle_id: '',
      service_type: '',
      description: '',
      cost: '',
      odometer_at_service: '',
      service_date: format(new Date(), 'yyyy-MM-dd'),
      completed: false,
    });
    setSelectedLog(null);
  };

  const getVehicleName = (vehicleId: string) => {
    return vehicles.find(v => v.id === vehicleId)?.name || 'Unknown';
  };

  const getTotalCost = () => {
    return logs.reduce((sum, log) => sum + log.cost, 0);
  };

  const getPendingServices = () => {
    return logs.filter(log => !log.completed).length;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Maintenance & Service Logs</h2>
          <p className="text-gray-600 mt-1">Track vehicle health and service history</p>
        </div>
        <Button onClick={() => { resetForm(); setDialogOpen(true); }} className="bg-gradient-to-r from-blue-600 to-indigo-600">
          <Plus className="size-4 mr-2" />
          Log Service
        </Button>
      </div>

      {/* Info Alert */}
      <Alert>
        <AlertCircle className="size-4" />
        <AlertDescription>
          <strong>Auto-Status Update:</strong> Adding a vehicle to maintenance automatically changes its status to "In Shop", 
          removing it from the Trip Dispatcher's available pool. Mark as completed to return it to "Available".
        </AlertDescription>
      </Alert>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{logs.length}</div>
            <p className="text-sm text-gray-600">Total Service Records</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{getPendingServices()}</div>
            <p className="text-sm text-gray-600">Pending Services</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">${getTotalCost().toLocaleString()}</div>
            <p className="text-sm text-gray-600">Total Maintenance Cost</p>
          </CardContent>
        </Card>
      </div>

      {/* Logs Table */}
      <Card>
        <CardHeader>
          <CardTitle>Service History</CardTitle>
          <CardDescription>All maintenance and repair records</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-gray-500">Loading logs...</div>
          ) : logs.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No maintenance logs found. Add your first service record.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Service Type</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Odometer</TableHead>
                    <TableHead>Cost</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="font-medium">{getVehicleName(log.vehicle_id)}</TableCell>
                      <TableCell>{log.service_type}</TableCell>
                      <TableCell className="max-w-xs truncate">{log.description}</TableCell>
                      <TableCell>{format(new Date(log.service_date), 'MMM dd, yyyy')}</TableCell>
                      <TableCell>{log.odometer_at_service.toLocaleString()} km</TableCell>
                      <TableCell>${log.cost.toLocaleString()}</TableCell>
                      <TableCell>
                        {log.completed ? (
                          <Badge className="bg-green-100 text-green-800">Completed</Badge>
                        ) : (
                          <Badge className="bg-orange-100 text-orange-800">In Progress</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button variant="ghost" size="sm" onClick={() => handleEdit(log)}>
                            Edit
                          </Button>
                          <Button 
                            size="sm" 
                            variant={log.completed ? "outline" : "default"}
                            onClick={() => handleToggleComplete(log)}
                            className={log.completed ? "" : "bg-green-600 hover:bg-green-700"}
                          >
                            {log.completed ? 'Reopen' : 'Complete'}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              <Wrench className="inline size-5 mr-2" />
              {selectedLog ? 'Edit Service Log' : 'Log New Service'}
            </DialogTitle>
            <DialogDescription>
              {selectedLog ? 'Update service record' : 'Record maintenance or repair work'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="vehicle_id">Vehicle *</Label>
                <Select 
                  value={formData.vehicle_id} 
                  onValueChange={(value) => setFormData({ ...formData, vehicle_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select vehicle" />
                  </SelectTrigger>
                  <SelectContent>
                    {vehicles.map(v => (
                      <SelectItem key={v.id} value={v.id}>
                        {v.name} ({v.license_plate})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="service_type">Service Type *</Label>
                  <Select 
                    value={formData.service_type} 
                    onValueChange={(value) => setFormData({ ...formData, service_type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Oil Change">Oil Change</SelectItem>
                      <SelectItem value="Tire Replacement">Tire Replacement</SelectItem>
                      <SelectItem value="Brake Service">Brake Service</SelectItem>
                      <SelectItem value="Engine Repair">Engine Repair</SelectItem>
                      <SelectItem value="Transmission Service">Transmission Service</SelectItem>
                      <SelectItem value="General Inspection">General Inspection</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="service_date">Service Date *</Label>
                  <Input
                    id="service_date"
                    type="date"
                    value={formData.service_date}
                    onChange={(e) => setFormData({ ...formData, service_date: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe the service or repair work performed..."
                  rows={3}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cost">Cost ($) *</Label>
                  <Input
                    id="cost"
                    type="number"
                    value={formData.cost}
                    onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
                    placeholder="e.g., 150.00"
                    required
                    min="0"
                    step="0.01"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="odometer_at_service">Odometer (km) *</Label>
                  <Input
                    id="odometer_at_service"
                    type="number"
                    value={formData.odometer_at_service}
                    onChange={(e) => setFormData({ ...formData, odometer_at_service: e.target.value })}
                    placeholder="e.g., 15000"
                    required
                    min="0"
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="completed"
                  checked={formData.completed}
                  onCheckedChange={(checked) => setFormData({ ...formData, completed: checked as boolean })}
                />
                <Label htmlFor="completed" className="cursor-pointer">
                  Mark as completed (vehicle will be set to Available)
                </Label>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => { setDialogOpen(false); resetForm(); }}>
                Cancel
              </Button>
              <Button type="submit" className="bg-gradient-to-r from-blue-600 to-indigo-600">
                {selectedLog ? 'Update Log' : 'Create Log'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};
