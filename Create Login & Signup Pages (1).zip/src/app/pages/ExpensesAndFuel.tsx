import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Plus, DollarSign, Fuel } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { FuelLog, Expense, Vehicle } from '../types/database';
import { toast } from 'sonner';
import { format } from 'date-fns';

export const ExpensesAndFuel: React.FC = () => {
  const [fuelLogs, setFuelLogs] = useState<FuelLog[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [fuelDialogOpen, setFuelDialogOpen] = useState(false);
  const [expenseDialogOpen, setExpenseDialogOpen] = useState(false);
  
  const [fuelFormData, setFuelFormData] = useState({
    vehicle_id: '',
    liters: '',
    cost: '',
    odometer: '',
    fuel_date: format(new Date(), 'yyyy-MM-dd'),
  });

  const [expenseFormData, setExpenseFormData] = useState({
    vehicle_id: '',
    category: 'Fuel' as 'Fuel' | 'Maintenance' | 'Insurance' | 'Other',
    amount: '',
    description: '',
    expense_date: format(new Date(), 'yyyy-MM-dd'),
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      const { data: fuelData, error: fuelError } = await supabase
        .from('fuel_logs')
        .select('*')
        .order('fuel_date', { ascending: false });
      
      if (fuelError) throw fuelError;
      setFuelLogs(fuelData || []);

      const { data: expenseData, error: expenseError } = await supabase
        .from('expenses')
        .select('*')
        .order('expense_date', { ascending: false });
      
      if (expenseError) throw expenseError;
      setExpenses(expenseData || []);

      const { data: vehiclesData, error: vehiclesError } = await supabase
        .from('vehicles')
        .select('*')
        .order('name');
      
      if (vehiclesError) throw vehiclesError;
      setVehicles(vehiclesData || []);
      
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const handleFuelSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const fuelData = {
        ...fuelFormData,
        liters: parseFloat(fuelFormData.liters),
        cost: parseFloat(fuelFormData.cost),
        odometer: parseFloat(fuelFormData.odometer),
      };

      const { error } = await supabase
        .from('fuel_logs')
        .insert([fuelData]);

      if (error) throw error;
      toast.success('Fuel log added successfully');
      setFuelDialogOpen(false);
      resetFuelForm();
      loadData();
    } catch (error: any) {
      console.error('Error saving fuel log:', error);
      toast.error(error.message || 'Failed to save fuel log');
    }
  };

  const handleExpenseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const expenseData = {
        ...expenseFormData,
        amount: parseFloat(expenseFormData.amount),
      };

      const { error } = await supabase
        .from('expenses')
        .insert([expenseData]);

      if (error) throw error;
      toast.success('Expense added successfully');
      setExpenseDialogOpen(false);
      resetExpenseForm();
      loadData();
    } catch (error: any) {
      console.error('Error saving expense:', error);
      toast.error(error.message || 'Failed to save expense');
    }
  };

  const resetFuelForm = () => {
    setFuelFormData({
      vehicle_id: '',
      liters: '',
      cost: '',
      odometer: '',
      fuel_date: format(new Date(), 'yyyy-MM-dd'),
    });
  };

  const resetExpenseForm = () => {
    setExpenseFormData({
      vehicle_id: '',
      category: 'Fuel',
      amount: '',
      description: '',
      expense_date: format(new Date(), 'yyyy-MM-dd'),
    });
  };

  const getVehicleName = (vehicleId: string) => {
    return vehicles.find(v => v.id === vehicleId)?.name || 'Unknown';
  };

  const getTotalFuelCost = () => {
    return fuelLogs.reduce((sum, log) => sum + log.cost, 0);
  };

  const getTotalExpenses = () => {
    return expenses.reduce((sum, exp) => sum + exp.amount, 0);
  };

  const getVehicleOperationalCost = (vehicleId: string) => {
    const fuelCost = fuelLogs
      .filter(f => f.vehicle_id === vehicleId)
      .reduce((sum, f) => sum + f.cost, 0);
    
    const maintenanceCost = expenses
      .filter(e => e.vehicle_id === vehicleId && e.category === 'Maintenance')
      .reduce((sum, e) => sum + e.amount, 0);
    
    return fuelCost + maintenanceCost;
  };

  const vehicleCostSummary = vehicles.map(v => ({
    ...v,
    totalCost: getVehicleOperationalCost(v.id),
  })).sort((a, b) => b.totalCost - a.totalCost);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Expenses & Fuel Logging</h2>
        <p className="text-gray-600 mt-1">Track operational costs and fuel consumption</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">${getTotalFuelCost().toLocaleString()}</div>
            <p className="text-sm text-gray-600">Total Fuel Cost</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">${getTotalExpenses().toLocaleString()}</div>
            <p className="text-sm text-gray-600">Total Expenses</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">${(getTotalFuelCost() + getTotalExpenses()).toLocaleString()}</div>
            <p className="text-sm text-gray-600">Combined Total</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs for Fuel and Expenses */}
      <Card>
        <CardHeader>
          <CardTitle>Financial Records</CardTitle>
          <CardDescription>Manage fuel logs and expenses</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="fuel">
            <div className="flex items-center justify-between mb-4">
              <TabsList>
                <TabsTrigger value="fuel">Fuel Logs ({fuelLogs.length})</TabsTrigger>
                <TabsTrigger value="expenses">Expenses ({expenses.length})</TabsTrigger>
                <TabsTrigger value="summary">Vehicle Summary</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="fuel">
              <div className="space-y-4">
                <div className="flex justify-end">
                  <Button onClick={() => setFuelDialogOpen(true)} className="bg-gradient-to-r from-blue-600 to-indigo-600">
                    <Plus className="size-4 mr-2" />
                    Add Fuel Log
                  </Button>
                </div>
                {loading ? (
                  <div className="text-center py-8 text-gray-500">Loading...</div>
                ) : fuelLogs.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">No fuel logs found</div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Vehicle</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Liters</TableHead>
                          <TableHead>Cost</TableHead>
                          <TableHead>Odometer</TableHead>
                          <TableHead>Price/L</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {fuelLogs.map((log) => (
                          <TableRow key={log.id}>
                            <TableCell className="font-medium">{getVehicleName(log.vehicle_id)}</TableCell>
                            <TableCell>{format(new Date(log.fuel_date), 'MMM dd, yyyy')}</TableCell>
                            <TableCell>{log.liters.toFixed(2)} L</TableCell>
                            <TableCell>${log.cost.toFixed(2)}</TableCell>
                            <TableCell>{log.odometer.toLocaleString()} km</TableCell>
                            <TableCell>${(log.cost / log.liters).toFixed(2)}/L</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="expenses">
              <div className="space-y-4">
                <div className="flex justify-end">
                  <Button onClick={() => setExpenseDialogOpen(true)} className="bg-gradient-to-r from-blue-600 to-indigo-600">
                    <Plus className="size-4 mr-2" />
                    Add Expense
                  </Button>
                </div>
                {loading ? (
                  <div className="text-center py-8 text-gray-500">Loading...</div>
                ) : expenses.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">No expenses found</div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Vehicle</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Description</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Amount</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {expenses.map((expense) => (
                          <TableRow key={expense.id}>
                            <TableCell className="font-medium">{getVehicleName(expense.vehicle_id)}</TableCell>
                            <TableCell>{expense.category}</TableCell>
                            <TableCell className="max-w-xs truncate">{expense.description}</TableCell>
                            <TableCell>{format(new Date(expense.expense_date), 'MMM dd, yyyy')}</TableCell>
                            <TableCell className="font-semibold">${expense.amount.toFixed(2)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="summary">
              <div className="space-y-4">
                <div className="text-sm text-gray-600 mb-4">
                  Total Operational Cost = Fuel + Maintenance per vehicle
                </div>
                {vehicleCostSummary.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">No vehicles found</div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Vehicle</TableHead>
                          <TableHead>License Plate</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Total Operational Cost</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {vehicleCostSummary.map((vehicle) => (
                          <TableRow key={vehicle.id}>
                            <TableCell className="font-medium">{vehicle.name}</TableCell>
                            <TableCell className="font-mono">{vehicle.license_plate}</TableCell>
                            <TableCell>{vehicle.vehicle_type}</TableCell>
                            <TableCell className="font-bold text-lg">
                              ${vehicle.totalCost.toLocaleString()}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Fuel Dialog */}
      <Dialog open={fuelDialogOpen} onOpenChange={setFuelDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              <Fuel className="inline size-5 mr-2" />
              Add Fuel Log
            </DialogTitle>
            <DialogDescription>Record fuel purchase and consumption</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleFuelSubmit}>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="fuel_vehicle_id">Vehicle *</Label>
                <Select 
                  value={fuelFormData.vehicle_id} 
                  onValueChange={(value) => setFuelFormData({ ...fuelFormData, vehicle_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select vehicle" />
                  </SelectTrigger>
                  <SelectContent>
                    {vehicles.map(v => (
                      <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="liters">Liters *</Label>
                  <Input
                    id="liters"
                    type="number"
                    value={fuelFormData.liters}
                    onChange={(e) => setFuelFormData({ ...fuelFormData, liters: e.target.value })}
                    placeholder="e.g., 45.5"
                    required
                    min="0"
                    step="0.1"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cost">Cost ($) *</Label>
                  <Input
                    id="cost"
                    type="number"
                    value={fuelFormData.cost}
                    onChange={(e) => setFuelFormData({ ...fuelFormData, cost: e.target.value })}
                    placeholder="e.g., 75.00"
                    required
                    min="0"
                    step="0.01"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="odometer">Odometer (km) *</Label>
                  <Input
                    id="odometer"
                    type="number"
                    value={fuelFormData.odometer}
                    onChange={(e) => setFuelFormData({ ...fuelFormData, odometer: e.target.value })}
                    placeholder="e.g., 15000"
                    required
                    min="0"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fuel_date">Date *</Label>
                  <Input
                    id="fuel_date"
                    type="date"
                    value={fuelFormData.fuel_date}
                    onChange={(e) => setFuelFormData({ ...fuelFormData, fuel_date: e.target.value })}
                    required
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => { setFuelDialogOpen(false); resetFuelForm(); }}>
                Cancel
              </Button>
              <Button type="submit" className="bg-gradient-to-r from-blue-600 to-indigo-600">
                Add Fuel Log
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Expense Dialog */}
      <Dialog open={expenseDialogOpen} onOpenChange={setExpenseDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              <DollarSign className="inline size-5 mr-2" />
              Add Expense
            </DialogTitle>
            <DialogDescription>Record vehicle-related expense</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleExpenseSubmit}>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="expense_vehicle_id">Vehicle *</Label>
                <Select 
                  value={expenseFormData.vehicle_id} 
                  onValueChange={(value) => setExpenseFormData({ ...expenseFormData, vehicle_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select vehicle" />
                  </SelectTrigger>
                  <SelectContent>
                    {vehicles.map(v => (
                      <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Category *</Label>
                  <Select 
                    value={expenseFormData.category} 
                    onValueChange={(value: any) => setExpenseFormData({ ...expenseFormData, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Fuel">Fuel</SelectItem>
                      <SelectItem value="Maintenance">Maintenance</SelectItem>
                      <SelectItem value="Insurance">Insurance</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount ($) *</Label>
                  <Input
                    id="amount"
                    type="number"
                    value={expenseFormData.amount}
                    onChange={(e) => setExpenseFormData({ ...expenseFormData, amount: e.target.value })}
                    placeholder="e.g., 250.00"
                    required
                    min="0"
                    step="0.01"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description *</Label>
                <Input
                  id="description"
                  value={expenseFormData.description}
                  onChange={(e) => setExpenseFormData({ ...expenseFormData, description: e.target.value })}
                  placeholder="Brief description of the expense"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="expense_date">Date *</Label>
                <Input
                  id="expense_date"
                  type="date"
                  value={expenseFormData.expense_date}
                  onChange={(e) => setExpenseFormData({ ...expenseFormData, expense_date: e.target.value })}
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => { setExpenseDialogOpen(false); resetExpenseForm(); }}>
                Cancel
              </Button>
              <Button type="submit" className="bg-gradient-to-r from-blue-600 to-indigo-600">
                Add Expense
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};
