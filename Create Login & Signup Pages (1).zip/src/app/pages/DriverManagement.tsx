import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Badge } from '../components/ui/badge';
import { Alert, AlertDescription } from '../components/ui/alert';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '../components/ui/alert-dialog';
import { Plus, Edit, Trash2, AlertCircle, Search } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Driver, DriverStatus } from '../types/database';
import { toast } from 'sonner';

export const DriverManagement: React.FC = () => {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedDriver, setSelectedDriver] = useState<Driver | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    license_number: '',
    license_expiry: '',
    license_category: '',
    status: 'On Duty' as DriverStatus,
    safety_score: '100',
    trip_completion_rate: '100',
  });

  useEffect(() => {
    loadDrivers();
  }, []);

  const loadDrivers = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('drivers')
        .select('*')
        .order('name');

      if (error) throw error;
      setDrivers(data || []);
    } catch (error) {
      console.error('Error loading drivers:', error);
      toast.error('Failed to load drivers');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const driverData = {
        ...formData,
        safety_score: parseFloat(formData.safety_score),
        trip_completion_rate: parseFloat(formData.trip_completion_rate),
      };

      if (selectedDriver) {
        const { error } = await supabase
          .from('drivers')
          .update(driverData)
          .eq('id', selectedDriver.id);

        if (error) throw error;
        toast.success('Driver updated successfully');
      } else {
        const { error } = await supabase
          .from('drivers')
          .insert([driverData]);

        if (error) throw error;
        toast.success('Driver added successfully');
      }

      setDialogOpen(false);
      resetForm();
      loadDrivers();
    } catch (error: any) {
      console.error('Error saving driver:', error);
      toast.error(error.message || 'Failed to save driver');
    }
  };

  const handleEdit = (driver: Driver) => {
    setSelectedDriver(driver);
    setFormData({
      name: driver.name,
      email: driver.email,
      phone: driver.phone,
      license_number: driver.license_number,
      license_expiry: driver.license_expiry,
      license_category: driver.license_category,
      status: driver.status,
      safety_score: driver.safety_score.toString(),
      trip_completion_rate: driver.trip_completion_rate.toString(),
    });
    setDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!selectedDriver) return;

    try {
      const { error } = await supabase
        .from('drivers')
        .delete()
        .eq('id', selectedDriver.id);

      if (error) throw error;
      toast.success('Driver deleted successfully');
      setDeleteDialogOpen(false);
      setSelectedDriver(null);
      loadDrivers();
    } catch (error: any) {
      console.error('Error deleting driver:', error);
      toast.error(error.message || 'Failed to delete driver');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      license_number: '',
      license_expiry: '',
      license_category: '',
      status: 'On Duty',
      safety_score: '100',
      trip_completion_rate: '100',
    });
    setSelectedDriver(null);
  };

  const getStatusBadge = (status: DriverStatus) => {
    const styles = {
      'On Duty': 'bg-green-100 text-green-800',
      'Off Duty': 'bg-gray-100 text-gray-800',
      'Suspended': 'bg-red-100 text-red-800',
      'On Trip': 'bg-blue-100 text-blue-800',
    };
    return <Badge className={styles[status]}>{status}</Badge>;
  };

  const isLicenseExpired = (expiryDate: string) => {
    return new Date(expiryDate) < new Date();
  };

  const filteredDrivers = drivers.filter(d =>
    d.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.license_number.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Driver Management</h2>
          <p className="text-gray-600 mt-1">Manage driver profiles, compliance, and performance</p>
        </div>
        <Button onClick={() => { resetForm(); setDialogOpen(true); }} className="bg-gradient-to-r from-blue-600 to-indigo-600">
          <Plus className="size-4 mr-2" />
          Add Driver
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{drivers.filter(d => d.status === 'On Duty').length}</div>
            <p className="text-sm text-gray-600">On Duty</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{drivers.filter(d => d.status === 'On Trip').length}</div>
            <p className="text-sm text-gray-600">On Trip</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{drivers.filter(d => isLicenseExpired(d.license_expiry)).length}</div>
            <p className="text-sm text-gray-600">Expired Licenses</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{drivers.length}</div>
            <p className="text-sm text-gray-600">Total Drivers</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
            <Input
              placeholder="Search by name, email, or license..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>All Drivers</CardTitle>
          <CardDescription>Complete driver roster with compliance tracking</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-gray-500">Loading drivers...</div>
          ) : filteredDrivers.length === 0 ? (
            <div className="text-center py-8 text-gray-500">No drivers found</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>License</TableHead>
                    <TableHead>Expiry</TableHead>
                    <TableHead>Safety Score</TableHead>
                    <TableHead>Completion Rate</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDrivers.map((driver) => {
                    const licenseExpired = isLicenseExpired(driver.license_expiry);
                    return (
                      <TableRow key={driver.id} className={licenseExpired ? 'bg-red-50' : ''}>
                        <TableCell className="font-medium">{driver.name}</TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <div>{driver.email}</div>
                            <div className="text-gray-500">{driver.phone}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <div className="font-mono">{driver.license_number}</div>
                            <div className="text-gray-500">{driver.license_category}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {driver.license_expiry}
                            {licenseExpired && (
                              <AlertCircle className="size-4 text-red-600" title="License expired" />
                            )}
                          </div>
                        </TableCell>
                        <TableCell>{driver.safety_score}/100</TableCell>
                        <TableCell>{driver.trip_completion_rate}%</TableCell>
                        <TableCell>{getStatusBadge(driver.status)}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button variant="ghost" size="sm" onClick={() => handleEdit(driver)}>
                              <Edit className="size-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => { setSelectedDriver(driver); setDeleteDialogOpen(true); }}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="size-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedDriver ? 'Edit Driver' : 'Add New Driver'}</DialogTitle>
            <DialogDescription>
              {selectedDriver ? 'Update driver information' : 'Enter details for the new driver'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone *</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="license_number">License Number *</Label>
                <Input
                  id="license_number"
                  value={formData.license_number}
                  onChange={(e) => setFormData({ ...formData, license_number: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="license_category">License Category *</Label>
                <Input
                  id="license_category"
                  value={formData.license_category}
                  onChange={(e) => setFormData({ ...formData, license_category: e.target.value })}
                  placeholder="e.g., Van, Truck"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="license_expiry">License Expiry *</Label>
                <Input
                  id="license_expiry"
                  type="date"
                  value={formData.license_expiry}
                  onChange={(e) => setFormData({ ...formData, license_expiry: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="safety_score">Safety Score (0-100) *</Label>
                <Input
                  id="safety_score"
                  type="number"
                  value={formData.safety_score}
                  onChange={(e) => setFormData({ ...formData, safety_score: e.target.value })}
                  min="0"
                  max="100"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="trip_completion_rate">Completion Rate (%) *</Label>
                <Input
                  id="trip_completion_rate"
                  type="number"
                  value={formData.trip_completion_rate}
                  onChange={(e) => setFormData({ ...formData, trip_completion_rate: e.target.value })}
                  min="0"
                  max="100"
                  required
                />
              </div>
              <div className="space-y-2 col-span-2">
                <Label htmlFor="status">Status *</Label>
                <Select value={formData.status} onValueChange={(value: DriverStatus) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="On Duty">On Duty</SelectItem>
                    <SelectItem value="Off Duty">Off Duty</SelectItem>
                    <SelectItem value="Suspended">Suspended</SelectItem>
                    <SelectItem value="On Trip">On Trip</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Alert className="mb-4">
              <AlertCircle className="size-4" />
              <AlertDescription>
                <strong>Compliance Note:</strong> Drivers with expired licenses will be blocked from trip assignment in the dispatcher.
              </AlertDescription>
            </Alert>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => { setDialogOpen(false); resetForm(); }}>
                Cancel
              </Button>
              <Button type="submit" className="bg-gradient-to-r from-blue-600 to-indigo-600">
                {selectedDriver ? 'Update Driver' : 'Add Driver'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete {selectedDriver?.name}. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setSelectedDriver(null)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
