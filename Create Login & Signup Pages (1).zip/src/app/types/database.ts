// Database types for FleetFlow

export type VehicleStatus = 'Available' | 'On Trip' | 'In Shop' | 'Out of Service';
export type VehicleType = 'Truck' | 'Van' | 'Bike';
export type DriverStatus = 'On Duty' | 'Off Duty' | 'Suspended' | 'On Trip';
export type TripStatus = 'Draft' | 'Dispatched' | 'Completed' | 'Cancelled';

export interface Vehicle {
  id: string;
  name: string;
  model: string;
  license_plate: string;
  vehicle_type: VehicleType;
  max_capacity: number; // in kg
  odometer: number; // in km
  status: VehicleStatus;
  region?: string;
  created_at: string;
  updated_at: string;
}

export interface Driver {
  id: string;
  name: string;
  email: string;
  phone: string;
  license_number: string;
  license_expiry: string;
  license_category: string;
  status: DriverStatus;
  safety_score: number; // 0-100
  trip_completion_rate: number; // 0-100
  created_at: string;
  updated_at: string;
}

export interface Trip {
  id: string;
  vehicle_id: string;
  driver_id: string;
  cargo_weight: number; // in kg
  origin: string;
  destination: string;
  distance: number; // in km
  status: TripStatus;
  start_odometer?: number;
  end_odometer?: number;
  started_at?: string;
  completed_at?: string;
  cancelled_at?: string;
  cancellation_reason?: string;
  created_at: string;
  updated_at: string;
}

export interface MaintenanceLog {
  id: string;
  vehicle_id: string;
  service_type: string;
  description: string;
  cost: number;
  odometer_at_service: number;
  service_date: string;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

export interface FuelLog {
  id: string;
  vehicle_id: string;
  trip_id?: string;
  liters: number;
  cost: number;
  odometer: number;
  fuel_date: string;
  created_at: string;
  updated_at: string;
}

export interface Expense {
  id: string;
  vehicle_id: string;
  category: 'Fuel' | 'Maintenance' | 'Insurance' | 'Other';
  amount: number;
  description: string;
  expense_date: string;
  created_at: string;
  updated_at: string;
}

// Extended types with relations
export interface TripWithRelations extends Trip {
  vehicle?: Vehicle;
  driver?: Driver;
}

export interface VehicleWithStats extends Vehicle {
  total_trips?: number;
  total_fuel_cost?: number;
  total_maintenance_cost?: number;
  total_distance?: number;
  fuel_efficiency?: number; // km/L
}
