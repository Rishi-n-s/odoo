import * as React from 'react';
import { supabase } from '../lib/supabase';

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: 'Fleet Manager' | 'Dispatcher' | 'Safety Officer' | 'Financial Analyst';
  created_at: string;
}

interface AuthContextType {
  user: UserProfile | null;
  accessToken: string | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, name: string, role: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = React.createContext<AuthContextType | undefined>(undefined);

export function useAuth() {
  const context = React.useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = React.useState<UserProfile | null>(null);
  const [accessToken, setAccessToken] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(true);

  const fetchUserProfile = React.useCallback(async (token: string, authUser?: any) => {
    try {
      if (!authUser) {
        const { data: { user: fetchedUser } } = await supabase.auth.getUser(token);
        authUser = fetchedUser;
      }
      
      if (authUser) {
        const { data: userProfile, error } = await supabase
          .from('users')
          .select('*')
          .eq('id', authUser.id)
          .single();
        
        if (!error && userProfile) {
          return userProfile as UserProfile;
        }
        
        if (authUser.user_metadata) {
          return {
            id: authUser.id,
            email: authUser.email || '',
            name: authUser.user_metadata.name || 'User',
            role: authUser.user_metadata.role || 'Fleet Manager',
            created_at: authUser.created_at,
          } as UserProfile;
        }
      }
      return null;
    } catch (error) {
      console.error('Error fetching user profile:', error);
      return null;
    }
  }, []);

  React.useEffect(() => {
    const checkSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) {
          setLoading(false);
          return;
        }
        if (session?.access_token) {
          setAccessToken(session.access_token);
          const profile = await fetchUserProfile(session.access_token);
          if (profile) setUser(profile);
        }
      } catch (error) {
        console.error('Error checking session:', error);
      } finally {
        setLoading(false);
      }
    };

    checkSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (session?.access_token) {
        setAccessToken(session.access_token);
        const profile = await fetchUserProfile(session.access_token);
        if (profile) setUser(profile);
      } else {
        setUser(null);
        setAccessToken(null);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchUserProfile]);

  const signIn = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw new Error(error.message);
    if (!data.session?.access_token) throw new Error('No access token received.');
    setAccessToken(data.session.access_token);
    const profile = await fetchUserProfile(data.session.access_token, data.user);
    if (!profile) throw new Error('Failed to load profile.');
    setUser(profile);
  };

  const signUp = async (email: string, password: string, name: string, role: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { name, role } },
    });
    if (error) throw new Error(error.message);
    if (!data.user) throw new Error('Signup failed.');
    
    if (data.session) {
      setAccessToken(data.session.access_token);
      const profile = await fetchUserProfile(data.session.access_token, data.user);
      if (profile) setUser(profile);
    } else {
      // If no session, it might be due to email confirmation being enabled
      // but since the user said they removed it, we'll just log it
      console.log('Signup successful, but no session returned. Email confirmation might be required.');
    }
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    setUser(null);
    setAccessToken(null);
  };

  const value = React.useMemo(() => ({
    user,
    accessToken,
    loading,
    signIn,
    signUp,
    signOut
  }), [user, accessToken, loading]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}
