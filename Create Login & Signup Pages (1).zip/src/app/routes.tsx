import { createBrowserRouter, Navigate } from "react-router";
import { LandingPage } from "./pages/LandingPage";
import { LoginPage } from "./pages/LoginPage";
import { SignupPage } from "./pages/SignupPage";
import { DashboardLayout } from "./layouts/DashboardLayout";
import { CommandCenter } from "./pages/CommandCenter";
import { VehicleRegistry } from "./pages/VehicleRegistry";
import { TripDispatcher } from "./pages/TripDispatcher";
import { MaintenanceLogs } from "./pages/MaintenanceLogs";
import { ExpensesAndFuel } from "./pages/ExpensesAndFuel";
import { DriverManagement } from "./pages/DriverManagement";
import { Analytics } from "./pages/Analytics";
import { UserProfile } from "./pages/UserProfile";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: LandingPage,
  },
  {
    path: "/login",
    Component: LoginPage,
  },
  {
    path: "/signup",
    Component: SignupPage,
  },
  {
    path: "/dashboard",
    Component: DashboardLayout,
    children: [
      {
        index: true,
        Component: CommandCenter,
      },
      {
        path: "vehicles",
        Component: VehicleRegistry,
      },
      {
        path: "trips",
        Component: TripDispatcher,
      },
      {
        path: "maintenance",
        Component: MaintenanceLogs,
      },
      {
        path: "expenses",
        Component: ExpensesAndFuel,
      },
      {
        path: "drivers",
        Component: DriverManagement,
      },
      {
        path: "analytics",
        Component: Analytics,
      },
      {
        path: "profile",
        Component: UserProfile,
      },
    ],
  },
  {
    path: "*",
    element: <Navigate to="/" replace />,
  },
]);
