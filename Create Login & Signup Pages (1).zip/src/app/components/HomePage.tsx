import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Truck, Users, Shield, TrendingUp, CheckCircle, MapPin, Calendar, DollarSign } from 'lucide-react';

interface HomePageProps {
  onShowLogin: () => void;
  onShowSignup: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onShowLogin, onShowSignup }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
              <Truck className="size-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              FleetFlow
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={onShowLogin}>
              Sign In
            </Button>
            <Button 
              onClick={onShowSignup}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              Get Started
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative container mx-auto px-4 py-24 overflow-hidden">
        {/* Animated background elements */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-blue-400/30 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-indigo-400/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
          <div className="absolute top-40 right-1/4 w-64 h-64 bg-purple-400/20 rounded-full blur-3xl animate-pulse delay-500"></div>
        </div>
        
        <div className="max-w-5xl mx-auto text-center relative">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-medium mb-6">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
            </span>
            Modern Fleet Management Solution
          </div>
          
          <h2 className="text-6xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Transform Your
            </span>
            <br />
            <span className="bg-gradient-to-r from-indigo-600 via-purple-600 to-blue-600 bg-clip-text text-transparent">
              Fleet Management
            </span>
          </h2>
          
          <p className="text-xl md:text-2xl text-gray-600 mb-10 leading-relaxed max-w-3xl mx-auto">
            Replace manual logbooks with a centralized, rule-based digital hub. 
            <span className="block mt-2 font-medium text-gray-700">
              Streamline operations, enhance safety, and maximize ROI.
            </span>
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button 
              size="lg"
              onClick={onShowSignup}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-lg px-12 py-7 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105"
            >
              Get Started
              <svg className="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </Button>
          </div>
          
          {/* Stats or Trust Indicators */}
          <div className="grid grid-cols-3 gap-8 max-w-2xl mx-auto mt-16 pt-8 border-t border-gray-200">
            <div>
              <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">500+</div>
              <div className="text-sm text-gray-600 mt-1">Fleets Managed</div>
            </div>
            <div>
              <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">99.9%</div>
              <div className="text-sm text-gray-600 mt-1">Uptime</div>
            </div>
            <div>
              <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">24/7</div>
              <div className="text-sm text-gray-600 mt-1">Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="container mx-auto px-4 py-16">
        <h3 className="text-3xl font-bold text-center mb-4 text-gray-800">
          Everything You Need to Manage Your Fleet
        </h3>
        <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
          Powerful features designed to streamline every aspect of your fleet operations
        </p>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          <Card className="relative overflow-hidden group hover:shadow-2xl transition-all duration-300 bg-gradient-to-br from-blue-50 to-white border-0">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-400/20 to-transparent rounded-bl-full"></div>
            <CardHeader className="relative">
              <div className="bg-gradient-to-br from-blue-500 to-blue-600 w-14 h-14 rounded-xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform">
                <Truck className="size-7 text-white" />
              </div>
              <CardTitle className="text-xl mb-2">Fleet Management</CardTitle>
              <CardDescription className="text-base text-gray-600 leading-relaxed">
                Track vehicle health, schedule maintenance, and manage your entire fleet from one centralized dashboard.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                  Vehicle tracking
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                  Maintenance scheduling
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                  Asset lifecycle management
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden group hover:shadow-2xl transition-all duration-300 bg-gradient-to-br from-green-50 to-white border-0">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-green-400/20 to-transparent rounded-bl-full"></div>
            <CardHeader className="relative">
              <div className="bg-gradient-to-br from-green-500 to-green-600 w-14 h-14 rounded-xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform">
                <MapPin className="size-7 text-white" />
              </div>
              <CardTitle className="text-xl mb-2">Trip Dispatch</CardTitle>
              <CardDescription className="text-base text-gray-600 leading-relaxed">
                Create trips, assign drivers, validate cargo loads, and track real-time delivery status updates.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                  Trip creation & assignment
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                  Cargo validation
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                  Real-time tracking
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden group hover:shadow-2xl transition-all duration-300 bg-gradient-to-br from-orange-50 to-white border-0">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-orange-400/20 to-transparent rounded-bl-full"></div>
            <CardHeader className="relative">
              <div className="bg-gradient-to-br from-orange-500 to-orange-600 w-14 h-14 rounded-xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform">
                <Shield className="size-7 text-white" />
              </div>
              <CardTitle className="text-xl mb-2">Safety & Compliance</CardTitle>
              <CardDescription className="text-base text-gray-600 leading-relaxed">
                Monitor driver compliance, track license expirations, and maintain comprehensive safety scores.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-orange-500"></div>
                  License monitoring
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-orange-500"></div>
                  Incident logging
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-orange-500"></div>
                  Safety score tracking
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden group hover:shadow-2xl transition-all duration-300 bg-gradient-to-br from-purple-50 to-white border-0">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-purple-400/20 to-transparent rounded-bl-full"></div>
            <CardHeader className="relative">
              <div className="bg-gradient-to-br from-purple-500 to-purple-600 w-14 h-14 rounded-xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform">
                <TrendingUp className="size-7 text-white" />
              </div>
              <CardTitle className="text-xl mb-2">Financial Analytics</CardTitle>
              <CardDescription className="text-base text-gray-600 leading-relaxed">
                Audit fuel spend, analyze maintenance ROI, and track operational costs in real-time.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-purple-500"></div>
                  Fuel cost auditing
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-purple-500"></div>
                  ROI analysis
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-purple-500"></div>
                  Cost per mile tracking
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Role-Based Access Section */}
      <section className="container mx-auto px-4 py-16 bg-white/50 rounded-3xl my-16">
        <h3 className="text-3xl font-bold text-center mb-12 text-gray-800">
          Built for Your Entire Team
        </h3>
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          <div className="flex gap-4">
            <div className="bg-gradient-to-br from-blue-500 to-indigo-500 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
              <Users className="size-6 text-white" />
            </div>
            <div>
              <h4 className="text-xl font-semibold mb-2 text-gray-800">Fleet Managers</h4>
              <p className="text-gray-600">
                Oversee vehicle health, manage asset lifecycle, optimize scheduling, and make data-driven decisions.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="bg-gradient-to-br from-green-500 to-emerald-500 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
              <MapPin className="size-6 text-white" />
            </div>
            <div>
              <h4 className="text-xl font-semibold mb-2 text-gray-800">Dispatchers</h4>
              <p className="text-gray-600">
                Create and assign trips, validate cargo loads, manage driver assignments, and track deliveries.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="bg-gradient-to-br from-orange-500 to-amber-500 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
              <Shield className="size-6 text-white" />
            </div>
            <div>
              <h4 className="text-xl font-semibold mb-2 text-gray-800">Safety Officers</h4>
              <p className="text-gray-600">
                Monitor compliance, track license expirations, log incidents, and maintain safety scores.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="bg-gradient-to-br from-purple-500 to-fuchsia-500 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
              <DollarSign className="size-6 text-white" />
            </div>
            <div>
              <h4 className="text-xl font-semibold mb-2 text-gray-800">Financial Analysts</h4>
              <p className="text-gray-600">
                Audit fuel spend, analyze maintenance ROI, calculate cost per mile, and generate revenue reports.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="container mx-auto px-4 py-16">
        <h3 className="text-3xl font-bold text-center mb-12 text-gray-800">
          Why Choose FleetFlow?
        </h3>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <div className="text-center">
            <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="size-8 text-green-600" />
            </div>
            <h4 className="text-xl font-semibold mb-2">Eliminate Manual Logbooks</h4>
            <p className="text-gray-600">
              Say goodbye to paper trails. Digitize every aspect of your fleet operations.
            </p>
          </div>

          <div className="text-center">
            <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Calendar className="size-8 text-blue-600" />
            </div>
            <h4 className="text-xl font-semibold mb-2">Real-Time Insights</h4>
            <p className="text-gray-600">
              Make informed decisions with live data and automated alerts.
            </p>
          </div>

          <div className="text-center">
            <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="size-8 text-purple-600" />
            </div>
            <h4 className="text-xl font-semibold mb-2">Maximize ROI</h4>
            <p className="text-gray-600">
              Reduce costs, improve efficiency, and boost your bottom line.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-3xl mx-auto bg-gradient-to-r from-blue-600 to-indigo-600 rounded-3xl p-12 text-white shadow-2xl">
          <h3 className="text-4xl font-bold mb-4">
            Ready to Optimize Your Fleet?
          </h3>
          <p className="text-xl mb-8 text-blue-100">
            Join hundreds of fleet managers who have transformed their operations with FleetFlow.
          </p>
          <Button 
            size="lg"
            onClick={onShowSignup}
            className="bg-white text-blue-600 hover:bg-gray-100 text-lg px-10 py-6"
          >
            Get Started
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-8 mt-20">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
              <Truck className="size-6 text-white" />
            </div>
            <span className="text-xl font-bold text-white">FleetFlow</span>
          </div>
          <p className="text-sm">
            © 2026 FleetFlow. All rights reserved. Your partner in fleet optimization.
          </p>
        </div>
      </footer>
    </div>
  );
};