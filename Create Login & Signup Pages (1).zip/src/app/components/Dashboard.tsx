import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { toast } from 'sonner';
import { 
  Truck, 
  LogOut, 
  Users, 
  BarChart3,
  Package,
  Shield,
  TrendingUp
} from 'lucide-react';

const roleIcons = {
  'Fleet Manager': Truck,
  'Dispatcher': Package,
  'Safety Officer': Shield,
  'Financial Analyst': TrendingUp,
};

const roleColors = {
  'Fleet Manager': 'bg-gradient-to-r from-blue-600 to-indigo-600',
  'Dispatcher': 'bg-gradient-to-r from-green-600 to-emerald-600',
  'Safety Officer': 'bg-gradient-to-r from-orange-600 to-amber-600',
  'Financial Analyst': 'bg-gradient-to-r from-purple-600 to-fuchsia-600',
};

const roleDashboards = {
  'Fleet Manager': {
    title: 'Fleet Overview',
    description: 'Manage vehicle health, asset lifecycle, and scheduling',
    metrics: [],
  },
  'Dispatcher': {
    title: 'Dispatch Center',
    description: 'Create trips, assign drivers, and validate cargo loads',
    metrics: [],
  },
  'Safety Officer': {
    title: 'Safety Dashboard',
    description: 'Monitor driver compliance, license expirations, and safety scores',
    metrics: [],
  },
  'Financial Analyst': {
    title: 'Financial Analytics',
    description: 'Audit fuel spend, maintenance ROI, and operational costs',
    metrics: [],
  },
};

export const Dashboard: React.FC = () => {
  const { user, signOut } = useAuth();

  if (!user) return null;

  const dashboardData = roleDashboards[user.role];
  const RoleIcon = roleIcons[user.role];
  const roleColor = roleColors[user.role];

  const handleSignOut = async () => {
    try {
      await signOut();
      toast.success('Signed out successfully');
    } catch (error) {
      toast.error('Failed to sign out');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`${roleColor} p-2 rounded-lg`}>
                <Truck className="size-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">FleetFlow</h1>
                <p className="text-sm text-gray-500">Fleet & Logistics Management</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-lg font-semibold text-gray-900">{user.name}</p>
                <Badge variant="outline" className="mt-1">
                  <RoleIcon className="size-3 mr-1" />
                  {user.role}
                </Badge>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleSignOut}
              >
                <LogOut className="size-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8 p-6 bg-white rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-3">
            Welcome back, {user.name}! 👋
          </h2>
          <p className="text-lg text-gray-600">{dashboardData.description}</p>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common tasks for your role</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button className="h-auto py-4 flex flex-col items-center gap-2" variant="outline">
                <Package className="size-6" />
                <span className="text-sm font-medium">
                  {user.role === 'Fleet Manager' ? 'Add Vehicle' : 
                   user.role === 'Dispatcher' ? 'Create Trip' :
                   user.role === 'Safety Officer' ? 'Log Incident' :
                   'Generate Report'}
                </span>
              </Button>
              <Button className="h-auto py-4 flex flex-col items-center gap-2" variant="outline">
                <BarChart3 className="size-6" />
                <span className="text-sm font-medium">View Reports</span>
              </Button>
              <Button className="h-auto py-4 flex flex-col items-center gap-2" variant="outline">
                <Users className="size-6" />
                <span className="text-sm font-medium">
                  {user.role === 'Dispatcher' ? 'Assign Driver' : 'View Team'}
                </span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};