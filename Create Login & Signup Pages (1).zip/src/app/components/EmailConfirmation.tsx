import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { CheckCircle2, XCircle, Loader2, Truck } from 'lucide-react';

interface EmailConfirmationProps {
  onGoToLogin: () => void;
}

export const EmailConfirmation: React.FC<EmailConfirmationProps> = ({ onGoToLogin }) => {
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('');
  const [countdown, setCountdown] = useState(3);

  useEffect(() => {
    const handleEmailConfirmation = async () => {
      try {
        // Check if this is an email confirmation by looking for the token in URL
        const hashParams = new URLSearchParams(window.location.hash.substring(1));
        const accessToken = hashParams.get('access_token');
        const refreshToken = hashParams.get('refresh_token');
        const type = hashParams.get('type');
        const errorDescription = hashParams.get('error_description');
        const error = hashParams.get('error');

        if (error || errorDescription) {
          setStatus('error');
          setMessage(errorDescription ? decodeURIComponent(errorDescription) : 'An error occurred during verification.');
          return;
        }

        if (type === 'signup' && accessToken) {
          // Set the session with the tokens from the URL
          if (refreshToken) {
            await supabase.auth.setSession({
              access_token: accessToken,
              refresh_token: refreshToken,
            });
          }

          // Email confirmation successful
          setStatus('success');
          setMessage('Your email has been verified successfully!');
          
          // Clear the hash from URL for cleaner look
          window.history.replaceState(null, '', window.location.pathname);
        } else if (type === 'recovery' && accessToken) {
          // Password recovery flow
          setStatus('success');
          setMessage('Password recovery link verified. Please set your new password.');
        } else {
          // No confirmation token found
          setStatus('error');
          setMessage('Invalid or expired confirmation link. Please try signing up again.');
        }
      } catch (err) {
        console.error('Email confirmation error:', err);
        setStatus('error');
        setMessage('An unexpected error occurred. Please try again.');
      }
    };

    handleEmailConfirmation();
  }, []);

  // Auto-redirect countdown for success
  useEffect(() => {
    if (status === 'success') {
      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            onGoToLogin();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [status, onGoToLogin]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-4">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-3 rounded-full shadow-lg">
              <Truck className="size-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            FleetFlow
          </CardTitle>
          <CardDescription className="text-base">Email Verification</CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {status === 'loading' && (
            <div className="text-center py-8">
              <Loader2 className="size-12 animate-spin text-blue-600 mx-auto mb-4" />
              <p className="text-gray-600">Verifying your email...</p>
            </div>
          )}

          {status === 'success' && (
            <>
              <Alert className="bg-green-50 border-green-200">
                <CheckCircle2 className="size-5 text-green-600" />
                <AlertDescription className="text-green-800">
                  <strong className="block mb-2">Email Verified Successfully! 🎉</strong>
                  <p className="text-sm">{message}</p>
                  <p className="text-sm mt-2">Redirecting to sign in in {countdown} second{countdown !== 1 ? 's' : ''}...</p>
                </AlertDescription>
              </Alert>

              <Button
                onClick={onGoToLogin}
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
              >
                Continue Now
              </Button>
            </>
          )}

          {status === 'error' && (
            <>
              <Alert variant="destructive">
                <XCircle className="size-5" />
                <AlertDescription>
                  <strong className="block mb-2">Verification Failed</strong>
                  <p className="text-sm">{message}</p>
                </AlertDescription>
              </Alert>

              <div className="space-y-3">
                <Button
                  onClick={onGoToLogin}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                >
                  Go to Sign In
                </Button>
                
                <p className="text-sm text-center text-gray-600">
                  Need help? The verification link may have expired. Try signing up again or contact support.
                </p>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};