# Supabase Database Migration Guide

## Current Issue

The application is showing database table errors because the Supabase migrations have not been run yet:

```
Error: Could not find the table 'public.vehicles' in the schema cache
Error: Could not find the table 'public.trips' in the schema cache
Error: Could not find the table 'public.drivers' in the schema cache
Error: Could not find the table 'public.fuel_logs' in the schema cache
```

## Solution: Run Database Migrations

You need to run the migrations to create all the FleetFlow database tables. Here's how:

### Option 1: Using Supabase CLI (Recommended)

1. **Install Supabase CLI** (if not already installed):
   ```bash
   npm install -g supabase
   ```

2. **Link your project** (if not already linked):
   ```bash
   supabase link --project-ref your-project-ref
   ```

3. **Run migrations**:
   ```bash
   supabase db push
   ```

### Option 2: Using Supabase Dashboard

1. Go to your Supabase project dashboard
2. Navigate to **SQL Editor**
3. Run each migration file in order:
   - `20260221000000_create_users_table.sql`
   - `20260221000001_fix_users_table.sql`
   - `20260221120000_create_fleet_tables.sql`
   - `20260221130000_seed_sample_data.sql`

### Option 3: Manual Reset (If tables exist but are broken)

If you need to start fresh:

```bash
supabase db reset
```

This will drop all tables and re-run all migrations from scratch.

## What the Migrations Create

The migrations will create these tables:
- **users** - User accounts with role-based access control
- **vehicles** - Fleet vehicle registry
- **drivers** - Driver profiles with license tracking
- **trips** - Trip dispatch and tracking
- **maintenance_logs** - Vehicle maintenance history
- **fuel_logs** - Fuel consumption records
- **expenses** - Vehicle expense tracking

## Verifying Success

After running migrations, you should be able to:
1. Log in to the application
2. See the Command Center dashboard
3. Access all 8 pages without database errors
4. View sample data (if you ran the seed migration)

## Troubleshooting

If you still see errors after running migrations:

1. **Refresh the schema cache**:
   - In Supabase Dashboard, go to Settings > API
   - Click "Reload schema cache"

2. **Check RLS policies**:
   - Make sure you're logged in as an authenticated user
   - The policies allow all authenticated users to access tables

3. **Verify connection**:
   - Check that your `/src/app/lib/supabase.ts` has the correct Supabase URL and anon key
   - Make sure the Supabase project is active and not paused

## Sample Data

The seed migration (`20260221130000_seed_sample_data.sql`) creates:
- 5 sample vehicles
- 5 sample drivers
- 10 sample trips
- Sample maintenance logs
- Sample fuel logs
- Sample expenses

This allows you to immediately see the application in action without manually entering data.
