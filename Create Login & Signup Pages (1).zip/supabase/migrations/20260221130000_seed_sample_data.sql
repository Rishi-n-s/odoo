-- Sample data for FleetFlow demonstration
-- This script populates the database with realistic test data

-- Insert sample vehicles
INSERT INTO vehicles (name, model, license_plate, vehicle_type, max_capacity, odometer, status, region) VALUES
  ('Truck-01', 'Ford F-150 2023', 'TRK-1001', 'Truck', 1500, 45200, 'Available', 'North'),
  ('Truck-02', 'Chevrolet Silverado 2022', 'TRK-1002', 'Truck', 1800, 32100, 'Available', 'South'),
  ('Van-01', 'Ford Transit 2023', 'VAN-2001', 'Van', 800, 28500, 'Available', 'East'),
  ('Van-02', 'Mercedes Sprinter 2023', 'VAN-2002', 'Van', 900, 19800, 'On Trip', 'West'),
  ('Van-03', 'Ram ProMaster 2022', 'VAN-2003', 'Van', 750, 41200, 'Available', 'North'),
  ('Bike-01', 'Honda CRF 250', 'BKE-3001', 'Bike', 50, 8500, 'Available', 'East'),
  ('Bike-02', 'Yamaha YZ 125', 'BKE-3002', 'Bike', 40, 6200, 'In Shop', 'South')
ON CONFLICT (license_plate) DO NOTHING;

-- Insert sample drivers
INSERT INTO drivers (name, email, phone, license_number, license_expiry, license_category, status, safety_score, trip_completion_rate) VALUES
  ('Alex Johnson', 'alex.johnson@fleetflow.com', '+1-555-0101', 'DL-12345678', '2026-12-31', 'Van', 'On Duty', 95, 98),
  ('Maria Garcia', 'maria.garcia@fleetflow.com', '+1-555-0102', 'DL-23456789', '2027-06-15', 'Truck', 'On Duty', 92, 96),
  ('James Chen', 'james.chen@fleetflow.com', '+1-555-0103', 'DL-34567890', '2025-03-20', 'Van', 'Off Duty', 88, 94),
  ('Sarah Williams', 'sarah.williams@fleetflow.com', '+1-555-0104', 'DL-45678901', '2026-09-10', 'Truck', 'On Trip', 97, 99),
  ('Michael Brown', 'michael.brown@fleetflow.com', '+1-555-0105', 'DL-56789012', '2024-11-30', 'Bike', 'Suspended', 75, 85),
  ('Emma Davis', 'emma.davis@fleetflow.com', '+1-555-0106', 'DL-67890123', '2027-01-25', 'Van', 'On Duty', 94, 97)
ON CONFLICT (email) DO NOTHING;

-- Insert sample completed trips
INSERT INTO trips (vehicle_id, driver_id, cargo_weight, origin, destination, distance, status, started_at, completed_at)
SELECT 
  v.id, 
  d.id, 
  450, 
  'Warehouse A', 
  'Distribution Center North', 
  125, 
  'Completed',
  NOW() - INTERVAL '5 days',
  NOW() - INTERVAL '4 days 20 hours'
FROM vehicles v, drivers d
WHERE v.license_plate = 'VAN-2001' AND d.email = 'alex.johnson@fleetflow.com'
ON CONFLICT DO NOTHING;

INSERT INTO trips (vehicle_id, driver_id, cargo_weight, origin, destination, distance, status, started_at, completed_at)
SELECT 
  v.id, 
  d.id, 
  1200, 
  'Factory B', 
  'Retail Store South', 
  200, 
  'Completed',
  NOW() - INTERVAL '3 days',
  NOW() - INTERVAL '2 days 18 hours'
FROM vehicles v, drivers d
WHERE v.license_plate = 'TRK-1001' AND d.email = 'maria.garcia@fleetflow.com'
ON CONFLICT DO NOTHING;

-- Insert sample active trip
INSERT INTO trips (vehicle_id, driver_id, cargo_weight, origin, destination, distance, status, started_at)
SELECT 
  v.id, 
  d.id, 
  650, 
  'Warehouse C', 
  'Distribution Center West', 
  180, 
  'Dispatched',
  NOW() - INTERVAL '6 hours'
FROM vehicles v, drivers d
WHERE v.license_plate = 'VAN-2002' AND d.email = 'sarah.williams@fleetflow.com'
ON CONFLICT DO NOTHING;

-- Insert sample draft trips
INSERT INTO trips (vehicle_id, driver_id, cargo_weight, origin, destination, distance, status)
SELECT 
  v.id, 
  d.id, 
  300, 
  'Warehouse A', 
  'Customer Location', 
  85, 
  'Draft'
FROM vehicles v, drivers d
WHERE v.license_plate = 'VAN-2003' AND d.email = 'emma.davis@fleetflow.com'
ON CONFLICT DO NOTHING;

-- Insert sample maintenance logs
INSERT INTO maintenance_logs (vehicle_id, service_type, description, cost, odometer_at_service, service_date, completed)
SELECT 
  v.id,
  'Oil Change',
  'Regular 10,000 km oil change service with filter replacement',
  150.00,
  40000,
  CURRENT_DATE - 30,
  true
FROM vehicles v WHERE v.license_plate = 'VAN-2003'
ON CONFLICT DO NOTHING;

INSERT INTO maintenance_logs (vehicle_id, service_type, description, cost, odometer_at_service, service_date, completed)
SELECT 
  v.id,
  'Brake Service',
  'Front brake pad replacement and rotor resurfacing',
  350.00,
  6000,
  CURRENT_DATE - 2,
  false
FROM vehicles v WHERE v.license_plate = 'BKE-3002'
ON CONFLICT DO NOTHING;

INSERT INTO maintenance_logs (vehicle_id, service_type, description, cost, odometer_at_service, service_date, completed)
SELECT 
  v.id,
  'Tire Replacement',
  'All four tires replaced due to wear',
  800.00,
  45000,
  CURRENT_DATE - 15,
  true
FROM vehicles v WHERE v.license_plate = 'TRK-1001'
ON CONFLICT DO NOTHING;

-- Insert sample fuel logs
INSERT INTO fuel_logs (vehicle_id, liters, cost, odometer, fuel_date)
SELECT v.id, 65.5, 98.25, 28300, CURRENT_DATE - 5
FROM vehicles v WHERE v.license_plate = 'VAN-2001'
ON CONFLICT DO NOTHING;

INSERT INTO fuel_logs (vehicle_id, liters, cost, odometer, fuel_date)
SELECT v.id, 45.2, 67.80, 28450, CURRENT_DATE - 2
FROM vehicles v WHERE v.license_plate = 'VAN-2001'
ON CONFLICT DO NOTHING;

INSERT INTO fuel_logs (vehicle_id, liters, cost, odometer, fuel_date)
SELECT v.id, 85.0, 127.50, 32000, CURRENT_DATE - 4
FROM vehicles v WHERE v.license_plate = 'TRK-1001'
ON CONFLICT DO NOTHING;

INSERT INTO fuel_logs (vehicle_id, liters, cost, odometer, fuel_date)
SELECT v.id, 55.3, 82.95, 19700, CURRENT_DATE - 6
FROM vehicles v WHERE v.license_plate = 'VAN-2002'
ON CONFLICT DO NOTHING;

-- Insert sample expenses
INSERT INTO expenses (vehicle_id, category, amount, description, expense_date)
SELECT v.id, 'Insurance', 1200.00, 'Annual vehicle insurance premium', CURRENT_DATE - 90
FROM vehicles v WHERE v.license_plate = 'TRK-1001'
ON CONFLICT DO NOTHING;

INSERT INTO expenses (vehicle_id, category, amount, description, expense_date)
SELECT v.id, 'Maintenance', 350.00, 'Brake service', CURRENT_DATE - 2
FROM vehicles v WHERE v.license_plate = 'BKE-3002'
ON CONFLICT DO NOTHING;

INSERT INTO expenses (vehicle_id, category, amount, description, expense_date)
SELECT v.id, 'Other', 75.00, 'Vehicle registration renewal', CURRENT_DATE - 60
FROM vehicles v WHERE v.license_plate = 'VAN-2002'
ON CONFLICT DO NOTHING;
