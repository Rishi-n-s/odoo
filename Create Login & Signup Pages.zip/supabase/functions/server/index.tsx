import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";

const app = new Hono();

// Create Supabase client with service role for admin operations
const getSupabaseAdmin = () => {
  return createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
  );
};

// Create Supabase client for regular auth operations
const getSupabaseClient = () => {
  return createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_ANON_KEY') ?? '',
  );
};

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-66ef3f16/health", (c) => {
  return c.json({ status: "ok" });
});

// Initialize demo user (idempotent)
app.post("/make-server-66ef3f16/init-demo", async (c) => {
  try {
    console.log('Init demo user request received');
    const supabase = getSupabaseAdmin();
    
    // Check if demo user already exists
    const { data: existingUsers, error: listError } = await supabase.auth.admin.listUsers();
    
    if (listError) {
      console.log(`Error listing users: ${listError.message}`);
      return c.json({ error: `Failed to list users: ${listError.message}` }, 500);
    }
    
    const demoUserExists = existingUsers?.users?.some(u => u.email === 'demo@fleetflow.com');
    
    if (demoUserExists) {
      console.log('Demo user already exists');
      return c.json({ success: true, message: 'Demo user already exists' });
    }

    console.log('Creating demo user...');
    // Create demo user
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email: 'demo@fleetflow.com',
      password: 'demo123',
      user_metadata: { name: 'Demo User', role: 'Fleet Manager' },
      email_confirm: true,
    });

    if (authError || !authData.user) {
      console.log(`Demo user creation error: ${authError?.message}`);
      return c.json({ error: `Failed to create demo user: ${authError?.message}` }, 400);
    }

    console.log(`Demo user created with ID: ${authData.user.id}`);

    return c.json({
      success: true,
      message: 'Demo user created successfully',
      user: {
        email: 'demo@fleetflow.com',
        name: 'Demo User',
        role: 'Fleet Manager',
      },
    });
  } catch (error) {
    console.log(`Init demo user error: ${error}`);
    return c.json({ error: `Failed to initialize demo user: ${error.message || error}` }, 500);
  }
});

// Signup endpoint - creates new user with role
app.post("/make-server-66ef3f16/signup", async (c) => {
  try {
    const body = await c.req.json();
    const { email, password, name, role } = body;

    // Validate inputs
    if (!email || !password || !name || !role) {
      return c.json({ error: "Missing required fields: email, password, name, role" }, 400);
    }

    // Validate role
    const validRoles = ['Fleet Manager', 'Dispatcher', 'Safety Officer', 'Financial Analyst'];
    if (!validRoles.includes(role)) {
      return c.json({ error: `Invalid role. Must be one of: ${validRoles.join(', ')}` }, 400);
    }

    const supabase = getSupabaseAdmin();

    // Create user with Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, role },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true,
    });

    if (authError) {
      console.log(`Signup error creating user: ${authError.message}`);
      return c.json({ error: `Failed to create user: ${authError.message}` }, 400);
    }

    if (!authData.user) {
      return c.json({ error: "User creation failed" }, 500);
    }

    return c.json({
      success: true,
      user: {
        id: authData.user.id,
        email: authData.user.email,
        name,
        role,
      },
    });
  } catch (error) {
    console.log(`Signup error: ${error}`);
    return c.json({ error: `Signup failed: ${error.message || error}` }, 500);
  }
});

// Get user profile endpoint (requires authentication)
app.get("/make-server-66ef3f16/profile", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "No authorization token provided" }, 401);
    }

    const supabase = getSupabaseAdmin();
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);

    if (error || !user) {
      console.log(`Profile fetch error - unauthorized: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Get user profile from database
    const { data: userProfile, error: profileError } = await supabase
      .from('users')
      .select('*')
      .eq('id', user.id)
      .single();

    if (profileError || !userProfile) {
      // Fallback to user metadata if database record doesn't exist
      console.log('No database profile found, using metadata');
      return c.json({
        success: true,
        profile: {
          id: user.id,
          email: user.email,
          name: user.user_metadata?.name || 'User',
          role: user.user_metadata?.role || 'Fleet Manager',
          created_at: user.created_at,
        },
      });
    }

    return c.json({
      success: true,
      profile: userProfile,
    });
  } catch (error) {
    console.log(`Profile fetch error: ${error}`);
    return c.json({ error: `Failed to fetch profile: ${error.message || error}` }, 500);
  }
});

Deno.serve(app.fetch);