import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { HomePage } from './components/HomePage';
import { LoginPage } from './components/LoginPage';
import { SignupPage } from './components/SignupPage';
import { Dashboard } from './components/Dashboard';
import { Toaster } from './components/ui/sonner';
import { Loader2 } from 'lucide-react';

const AppContent: React.FC = () => {
  const { user, loading } = useAuth();
  const [currentView, setCurrentView] = useState<'home' | 'login' | 'signup'>('home');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Loader2 className="size-12 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading FleetFlow...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    if (currentView === 'login') {
      return <LoginPage onSwitchToSignup={() => setCurrentView('signup')} onBackToHome={() => setCurrentView('home')} />;
    }
    
    if (currentView === 'signup') {
      return <SignupPage onSwitchToLogin={() => setCurrentView('login')} onBackToHome={() => setCurrentView('home')} />;
    }
    
    return <HomePage onShowLogin={() => setCurrentView('login')} onShowSignup={() => setCurrentView('signup')} />;
  }

  return <Dashboard />;
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
      <Toaster />
    </AuthProvider>
  );
}