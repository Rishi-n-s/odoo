import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: 'Fleet Manager' | 'Dispatcher' | 'Safety Officer' | 'Financial Analyst';
  created_at: string;
}

interface AuthContextType {
  user: UserProfile | null;
  accessToken: string | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, name: string, role: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  // Fetch user profile from backend or user metadata
  const fetchUserProfile = React.useCallback(async (token: string, authUser?: any) => {
    try {
      // Get auth user if not provided
      if (!authUser) {
        const { data: { user: fetchedUser } } = await supabase.auth.getUser(token);
        authUser = fetchedUser;
      }
      
      if (authUser) {
        // Try to get from users table first (primary source)
        const { data: userProfile, error } = await supabase
          .from('users')
          .select('*')
          .eq('id', authUser.id)
          .single();
        
        if (!error && userProfile) {
          console.log('✅ Profile loaded from database:', userProfile);
          return userProfile as UserProfile;
        }
        
        console.warn('⚠️ Profile not found in database, using metadata fallback');
        
        // Fallback to user metadata
        if (authUser.user_metadata) {
          return {
            id: authUser.id,
            email: authUser.email || '',
            name: authUser.user_metadata.name || 'User',
            role: authUser.user_metadata.role || 'Fleet Manager',
            created_at: authUser.created_at,
          } as UserProfile;
        }
      }
      
      return null;
    } catch (error) {
      console.error('Error fetching user profile:', error);
      
      // Try to get from auth user metadata as fallback
      try {
        const { data: { user: authUser } } = await supabase.auth.getUser(token);
        if (authUser?.user_metadata) {
          return {
            id: authUser.id,
            email: authUser.email || '',
            name: authUser.user_metadata.name || 'User',
            role: authUser.user_metadata.role || 'Fleet Manager',
            created_at: authUser.created_at,
          } as UserProfile;
        }
      } catch (fallbackError) {
        console.error('Fallback profile fetch failed:', fallbackError);
      }
      
      return null;
    }
  }, []);

  // Check for existing session on mount
  useEffect(() => {
    const checkSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('Session check error:', error);
          setLoading(false);
          return;
        }

        if (session?.access_token) {
          setAccessToken(session.access_token);
          const profile = await fetchUserProfile(session.access_token);
          if (profile) {
            setUser(profile);
          }
        }
      } catch (error) {
        console.error('Error checking session:', error);
      } finally {
        setLoading(false);
      }
    };

    checkSession();

    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('Auth state changed:', event);
      
      if (session?.access_token) {
        setAccessToken(session.access_token);
        const profile = await fetchUserProfile(session.access_token);
        if (profile) {
          setUser(profile);
        }
      } else {
        setUser(null);
        setAccessToken(null);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchUserProfile]);

  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        // Provide more helpful error messages
        if (error.message.includes('Invalid login credentials')) {
          throw new Error('Invalid email or password. Please check your credentials and try again.');
        } else if (error.message.includes('User not found')) {
          throw new Error('No account found with this email. Please sign up first.');
        }
        throw new Error(error.message);
      }

      if (!data.session?.access_token) {
        throw new Error('No access token received. Please try again or contact support.');
      }

      setAccessToken(data.session.access_token);
      const profile = await fetchUserProfile(data.session.access_token, data.user);
      
      if (!profile) {
        throw new Error('Failed to load your profile. Please try signing in again.');
      }

      setUser(profile);
    } catch (error) {
      console.error('Sign in error:', error);
      throw error;
    }
  };

  const signUp = async (email: string, password: string, name: string, role: string) => {
    try {
      console.log('🔄 Starting signup process for:', email);
      
      // Sign up with Supabase Auth (no email confirmation required)
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
            role,
          },
        },
      });

      console.log('📝 Signup response:', { 
        hasUser: !!data.user, 
        hasSession: !!data.session,
        userEmail: data.user?.email,
        error: error?.message 
      });

      if (error) {
        // Provide more helpful error messages
        if (error.message.includes('rate limit') || error.message.includes('Email rate limit exceeded')) {
          throw new Error('Too many signup attempts. Please wait a few minutes and try again.');
        } else if (error.message.includes('already registered')) {
          throw new Error('An account with this email already exists. Please try signing in instead.');
        }
        throw new Error(error.message);
      }

      if (!data.user) {
        throw new Error('Signup failed - no user returned. Please try again.');
      }

      // Check if email confirmation is required (user exists but no identities)
      if (data.user.identities && data.user.identities.length === 0) {
        throw new Error('Email already registered. Please sign in or use a different email.');
      }

      // If no session, email confirmation is enabled
      if (!data.session) {
        throw new Error('Email confirmation is required. Please check your email and click the confirmation link. If you don\'t see it, check your Supabase settings to disable email confirmation.');
      }

      console.log('✅ User created successfully:', data.user.email);

      // Automatically sign in the user
      setAccessToken(data.session.access_token);
      const profile = await fetchUserProfile(data.session.access_token, data.user);
      
      if (!profile) {
        throw new Error('Failed to load your profile. Please try signing in.');
      }

      setUser(profile);
    } catch (error) {
      console.error('Sign up error:', error);
      throw error;
    }
  };

  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      
      setUser(null);
      setAccessToken(null);
    } catch (error) {
      console.error('Sign out error:', error);
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{ user, accessToken, loading, signIn, signUp, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};