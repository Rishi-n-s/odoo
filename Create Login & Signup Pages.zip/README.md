
  # Create Login & Signup Pages

  This is a code bundle for Create Login & Signup Pages. The original project is available at https://www.figma.com/design/0VRq5sjR2ayebvP0hzSKIZ/Create-Login---Signup-Pages.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  